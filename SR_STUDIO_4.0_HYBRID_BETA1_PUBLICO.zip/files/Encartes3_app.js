(() => {
'use strict';

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const uid = (p='el') => `${p}_${Math.random().toString(36).slice(2,10)}_${Date.now().toString(36).slice(-4)}`;
const clone = x => JSON.parse(JSON.stringify(x));
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const money = v => {
  if(v===null||v===undefined||String(v).trim()==='') return '';
  let s=String(v).replace('R$','').trim(); let n=Number(s.includes(',')?s.replace(/\./g,'').replace(',','.'):s);
  return Number.isFinite(n)?n.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}):String(v);
};
const api = async (path, opts={}) => {
  const r = await fetch(path, opts);
  const type = r.headers.get('content-type')||'';
  const data = type.includes('json') ? await r.json() : await r.text();
  if(!r.ok || (data && data.ok===false)) throw new Error((data&&data.error)||`Falha ${r.status}`);
  return data;
};
const postJSON = (path,obj) => api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});

const state = {
  project:null, pageIndex:0, selected:[], primary:null, zoom:.65, grid:true, snap:true,
  history:[], future:[], clipboard:[], styleClipboard:null, campaigns:[], campaignItems:[],
  currentCampaign:null, dragging:null, resizing:null, rotating:null, pendingTextClick:null, textEditing:null, masterEdit:false,
  dataMode:false, bootstrap:null, dirty:false, autosaveTimer:null, snapshots:[], fonts:{installed:[],custom:[]},
  lastAnalysis:null, guides:[], comments:[], pro:{outline:false,performance:false,safeZones:false,lastOrchestration:null}, favorites:JSON.parse(localStorage.getItem('sr3_favorites')||'[]'), components:JSON.parse(localStorage.getItem('sr3_components')||'[]'),
};

const COLORS = {blue:'#0B53B6',navy:'#173A6B',red:'#E02F2F',yellow:'#F5C542',text:'#10213A',white:'#FFFFFF'};
const PRODUCT_CARD_DEFAULT = {fill:'#FFFFFF',radius:14,shadow:true,nameColor:'#10213A',priceColor:'#10213A',accent:'#0B53B6',imageFit:'contain'};


// 3.0.9 — camada de segurança: um controle ausente não pode derrubar o editor inteiro.
function reportUiError(error, context='Interface'){
  const message=String(error?.message||error||'Erro desconhecido');
  console.error(`[SR Studio 3.1.1] ${context}:`,error);
  const banner=document.getElementById('uiErrorBanner'),txt=document.getElementById('uiErrorText');
  if(banner&&txt){txt.textContent=`${context}: ${message}`;banner.classList.remove('hidden');}
  try{fetch('/api/ui-error',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({context,message,stack:String(error?.stack||''),at:new Date().toISOString()})}).catch(()=>{});}catch{}
}
function safeHandler(context, fn){
  return function(...args){
    try{const out=fn.apply(this,args);if(out&&typeof out.then==='function')out.catch(err=>reportUiError(err,context));return out;}
    catch(err){reportUiError(err,context);}
  };
}
function bindOptional(selector,event,fn,context=selector){
  const el=document.querySelector(selector);if(!el){console.warn(`[SR 3.1.1] Controle opcional ausente: ${selector}`);return null;}
  el.addEventListener(event,safeHandler(context,fn));return el;
}
function bindOptionalId(id,event,fn,context=id){return bindOptional('#'+id,event,fn,context);}
window.addEventListener('error',ev=>reportUiError(ev.error||ev.message,'JavaScript'));
window.addEventListener('unhandledrejection',ev=>reportUiError(ev.reason,'Tarefa assíncrona'));

function blankProject(){
  return {format:'SR_ENCARTE_PROJECT',version:4,title:'Novo Encarte',status:'RASCUNHO',campaignId:null,theme:'GENÉRICO',created_at:new Date().toISOString(),updated_at:new Date().toISOString(),
    master:{elements:[]}, brand:{primary:COLORS.blue,secondary:COLORS.navy,accent:COLORS.red},
    pages:[blankPage('Página 1')], comments:[], revisions:[], audit:[]};
}
function blankPage(name='Página 1',w=1080,h=1350){return {id:uid('page'),name,width:w,height:h,backgroundColor:'#FFFFFF',backgroundUrl:'',background_path:'',elements:[]};}
function page(){return state.project.pages[state.pageIndex];}
function elements(){return state.masterEdit ? (state.project.master.elements||[]) : page().elements;}
function allDisplayElements(){return [...(state.project.master.elements||[]).map(e=>({...e,_master:true})),...page().elements];}
function findEl(id){
  let e=(page().elements||[]).find(x=>x.id===id); if(e)return e;
  return (state.project.master.elements||[]).find(x=>x.id===id);
}
function markDirty(msg='Alterações não salvas'){
  state.dirty=true; state.project.updated_at=new Date().toISOString(); setStatus(msg,true); scheduleAutosave();
}
function snapshot(label='Alteração'){
  if(state.project){state.project.audit=state.project.audit||[];state.project.audit.push({at:new Date().toISOString(),action:label,user:state.bootstrap?.user||'USUÁRIO'});if(state.project.audit.length>500)state.project.audit=state.project.audit.slice(-500);}
  const snap=JSON.stringify(state.project); const last=state.history[state.history.length-1];
  if(!last || last.data!==snap){state.history.push({label,data:snap}); if(state.history.length>80)state.history.shift();}
  state.future=[];
}
function undo(){if(state.history.length<2)return; const cur=state.history.pop();state.future.push(cur);state.project=JSON.parse(state.history[state.history.length-1].data);state.pageIndex=Math.min(state.pageIndex,state.project.pages.length-1);clearSelection();renderAll();markDirty('Desfeito');}
function redo(){if(!state.future.length)return;const next=state.future.pop();state.history.push(next);state.project=JSON.parse(next.data);renderAll();markDirty('Refeito');}

function toast(msg,type=''){const el=document.createElement('div');el.className=`toast ${type}`;el.textContent=msg;$('#toastHost').append(el);setTimeout(()=>el.remove(),3300);}
function setStatus(msg,warn=false){$('#statusText').textContent=msg;$('#syncDot').classList.toggle('warn',!!warn);}
function openModal(title,html){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=html;$('#modal').classList.remove('hidden');}
function closeModal(){$('#modal').classList.add('hidden');}
function normFont(s){return String(s||'').toLowerCase().replace(/[^a-z0-9à-ÿ]+/g,' ').replace(/\b(regular|medium|bold|italic|semibold|black|light|thin|condensed)\b/g,' ').replace(/\s+/g,' ').trim();}
function allFontFamilies(){const a=[...(state.fonts.installed||[]),...(state.fonts.custom||[]).map(f=>f.family)].filter(Boolean);return [...new Set(a)].sort((x,y)=>x.localeCompare(y,'pt-BR',{sensitivity:'base'}));}
function fontKnown(name){const n=normFont(name);if(!n)return true;return allFontFamilies().some(x=>normFont(x)===n||normFont(x).startsWith(n)||n.startsWith(normFont(x)));}
function bestFontMatch(name){const n=normFont(name);if(!n)return '';const fonts=allFontFamilies();let exact=fonts.find(f=>normFont(f)===n);if(exact)return exact;let candidates=fonts.filter(f=>{const x=normFont(f);return x&&((n.startsWith(x)&&x.length>=4)||(x.startsWith(n)&&n.length>=4));});return candidates.sort((a,b)=>normFont(b).length-normFont(a).length)[0]||'';}
function autoMapProjectFonts(){if(!state.project)return 0;let n=0;const walk=e=>{if(e?.type==='text'&&e.style?.font){const current=e.style.font,match=bestFontMatch(current);if(match&&current!==match&&!state.fonts.installed.some(f=>normFont(f)===normFont(current))){e.style.font=match;n++;}}for(const c of e?.children||[])walk(c);};for(const pg of state.project.pages||[])for(const e of pg.elements||[])walk(e);for(const e of state.project.master?.elements||[])walk(e);return n;}
async function loadFontCatalog(data){
  state.fonts.installed=[...(data?.installed||[])];state.fonts.custom=[...(data?.custom||[])];
  for(const f of state.fonts.custom)await registerCustomFont(f);
  refreshFontSelectors();
}
async function registerCustomFont(f){
  if(!f?.url||!f?.family)return;try{const face=new FontFace(f.family,`url("${f.url}")`);const loaded=await face.load();document.fonts.add(loaded);}catch(err){console.warn('Fonte',f.family,err);}
}
function fillFontSelect(sel,current=''){
  if(!sel)return;const prior=current||sel.value||'';sel.innerHTML='';const fonts=allFontFamilies();
  if(prior&&!fonts.some(f=>normFont(f)===normFont(prior))){const o=new Option(`⚠ ${prior} (não instalada)`,prior);o.dataset.missing='1';sel.add(o);}
  for(const f of fonts)sel.add(new Option(f,f));if(prior)sel.value=prior;else if(fonts.includes('Segoe UI'))sel.value='Segoe UI';
}
function refreshFontSelectors(){fillFontSelect($('#fontSelect'));fillFontSelect($('#quickFontSelect'));const st=$('#fontStatus');if(st)st.textContent=`${state.fonts.installed.length} fontes do Windows • ${state.fonts.custom.length} fontes importadas no SR Studio.`;}
async function importFonts(files){
  const list=[...(files||[])];if(!list.length)return;setStatus(`Importando ${list.length} fonte(s)...`,true);
  let ok=0;for(const file of list){try{const r=await uploadFile(file,'/api/font/upload');state.fonts.custom.push(r);await registerCustomFont(r);ok++;}catch(e){toast(`${file.name}: ${e.message}`,'bad');}}
  refreshFontSelectors();const mapped=autoMapProjectFonts();if(mapped){markDirty('Fontes mapeadas');snapshot('Mapeamento de fontes');renderAll();}setStatus(`${ok} fonte(s) importadas`);toast(`${ok} fonte(s) adicionadas ao Gerenciador de Fontes${mapped?` • ${mapped} texto(s) mapeado(s)`:''}.`,'good');
  const e=state.primary?findEl(state.primary):null;if(e?.type==='text'&&!fontKnown(e.style?.font))renderProperties();
}
function applyFontToSelection(font){
  font=font||$('#fontSelect')?.value||'';if(!font)return;let n=0;for(const id of state.selected){const e=findEl(id);if(e?.type==='text'){e.style=e.style||{};e.style.font=font;n++;}}
  if(!n)return toast('Selecione pelo menos uma caixa de texto.');markDirty('Fonte alterada');snapshot('Fonte');renderAll();
}
function syncTextQuickToolbar(){
  const bar=$('#textQuickToolbar'),e=state.primary?findEl(state.primary):null;if(!bar)return;const show=e?.type==='text';bar.classList.toggle('hidden',!show);if(!show)return;
  fillFontSelect($('#quickFontSelect'),e.style?.font||'Segoe UI');$('#quickFontSize').value=Math.round(e.style?.fontSize||32);$('#quickBold').classList.toggle('active',!!e.style?.bold);$('#quickItalic').classList.toggle('active',!!e.style?.italic);$('#quickTextColor').value=e.style?.color||COLORS.text;
}

async function bootstrap(){
  try{
    state.bootstrap=await api('/api/bootstrap'); state.campaigns=state.bootstrap.campaigns||[];
    await loadFontCatalog(state.bootstrap.fonts||{});
    buildPresets(); buildTemplates(); buildCampaigns(); buildRecents(); renderComponents();
    state.project=blankProject(); snapshot('Projeto criado'); renderAll();
    if(state.bootstrap.hasRecovery){toast('Existe uma recuperação automática disponível. Veja em Projetos.');}
    setStatus(`Motor ${state.bootstrap.version} pronto`);
  }catch(e){toast('Falha ao iniciar: '+e.message,'bad'); state.project=blankProject();snapshot('Projeto criado');renderAll();}
}

function buildPresets(){
  const box=$('#presetGrid');box.innerHTML=''; const sel=$('#resizePreset');sel.innerHTML='';
  Object.entries((state.bootstrap&&state.bootstrap.pagePresets)||{FEED:[1080,1350],STORY:[1080,1920],A4:[1240,1754]}).forEach(([name,wh])=>{
    const b=document.createElement('button');b.className='presetCard';b.innerHTML=`${name}<span>${wh[0]} × ${wh[1]}</span>`;b.onclick=()=>resizeCurrentPage(wh[0],wh[1],false);box.append(b);
    sel.add(new Option(`${name} — ${wh[0]}×${wh[1]}`,`${wh[0]}x${wh[1]}`));
  });
}
function buildTemplates(){
  const list=[
    ['EM BRANCO','Página limpa','blank'],['GRADE 3×3','9 produtos','grid9'],['DESTAQUE + 6','Hero comercial','hero6'],['QUINTA FILÉ','Carnes / impacto','quinta'],['TERÇA VERDE','Hortifruti','verde'],['CLUBE','Preço Clube','clube']
  ]; const box=$('#templateGrid');box.innerHTML='';
  for(const [name,sub,id] of list){const b=document.createElement('button');b.className='templateCard';b.innerHTML=`${name}<span>${sub}</span>`;b.onclick=()=>applyStarterTemplate(id);box.append(b);}for(const t of (state.bootstrap?.templates||[])){const b=document.createElement('button');b.className='templateCard';b.innerHTML=`${escapeHTML(t.name)}<span>Modelo SR salvo</span>`;b.onclick=()=>openSavedTemplate(t.name);box.append(b);}
}
function buildCampaigns(){
  const s=$('#campaignSelect');s.innerHTML='<option value="">Selecionar campanha...</option>';
  state.campaigns.forEach(c=>s.add(new Option(`${c.name}${c.validity?' • '+c.validity:''}`,c.id)));
}
function buildRecents(){
  const box=$('#recentList');box.innerHTML='';
  (state.bootstrap&&state.bootstrap.recent||[]).forEach(r=>{const d=document.createElement('div');d.className='recent';d.textContent=r.name;d.onclick=()=>openRecent(r.name);box.append(d);});
  if(state.bootstrap&&state.bootstrap.hasRecovery){const d=document.createElement('div');d.className='recent';d.innerHTML='<b>↻ Recuperar autosave</b>';d.onclick=recoverProject;box.prepend(d);}
}

function setPanel(name){
  $$('.tool').forEach(x=>x.classList.toggle('active',x.dataset.panel===name));
  $$('[data-panel-body]').forEach(x=>x.classList.toggle('active',x.dataset.panelBody===name));
  const titles={templates:['Modelos','Templates e importação'],products:['Produtos','Campanhas e Produto Vivo'],elements:['Elementos','Formas, zonas e grupos'],text:['Texto','Tipografia e estilos'],uploads:['Imagens','Uploads e ajustes'],brand:['Marca SR','Kit de marca e master'],assistant:['SR IA','Assistente especializado'],pages:['Páginas','Miniaturas e Magic Resize'],projects:['Projetos','Salvar, recuperar e versões']};
  const t=titles[name]||[name,''];$('#drawerTitle').textContent=t[0];$('#drawerSubtitle').textContent=t[1];
}

function renderAll(){renderStage();renderPages();renderLayers();renderProperties();renderDataMode();syncProjectControls();syncTextQuickToolbar();}
function syncProjectControls(){if(!state.project)return;$('#projectTitle').value=state.project.title||'';$('#projectStatus').value=state.project.status||'RASCUNHO';$('#modeToggle').textContent=state.dataMode?'DADOS':'DESIGN';}
function renderStage(){
  const p=page(),stage=$('#stage'),wrap=$('#stageWrap'); if(!p)return;
  stage.innerHTML='';stage.style.width=p.width+'px';stage.style.height=p.height+'px';stage.style.backgroundColor=p.backgroundColor||'#fff';stage.classList.toggle('grid',state.grid);
  stage.style.transform=`scale(${state.zoom})`;wrap.style.width=(p.width*state.zoom)+'px';wrap.style.height=(p.height*state.zoom)+'px';
  if(p.backgroundUrl){const bg=document.createElement('img');bg.className='bgLayer';bg.src=p.backgroundUrl;stage.append(bg);}
  (state.project.master.elements||[]).forEach(e=>renderElement(e,stage,true));
  (p.elements||[]).forEach(e=>renderElement(e,stage,false));
  for(const g of state.guides||[]){const d=document.createElement('div');d.className='guide '+(g.axis==='v'?'v':'h');if(g.axis==='v')d.style.left=g.value+'px';else d.style.top=g.value+'px';stage.append(d);}
  $('#zoomLabel').textContent=Math.round(state.zoom*100)+'%';$('#zoomRange').value=Math.round(state.zoom*100);
}
function renderElement(e,host,isMaster=false){
  if(e.hidden)return;const node=document.createElement('div');node.className='sceneEl';node.dataset.id=e.id; if(e.locked)node.classList.add('locked'); if(isMaster)node.classList.add('masterEl');
  if(state.selected.includes(e.id))node.classList.add(e.id===state.primary?'selected':'multiSelected');if(state.textEditing?.id===e.id)node.classList.add('textEditing');
  Object.assign(node.style,{left:(e.x||0)+'px',top:(e.y||0)+'px',width:(e.w||100)+'px',height:(e.h||100)+'px',transform:`rotate(${e.rotation||0}deg)`,opacity:(e.opacity??1),zIndex:e.z||1});
  if(e.type==='text')renderText(e,node); else if(e.type==='shape')renderShape(e,node); else if(e.type==='image')renderImage(e,node); else if(e.type==='slot')renderSlot(e,node); else if(e.type==='product')renderProduct(e,node); else if(e.type==='group')renderGroup(e,node);
  if(e.templateRole&&state.selected.includes(e.id)){const b=document.createElement('div');b.className='smartRoleBadge';b.textContent=`${e.templateRole}${e.slotIndex?` • ${e.slotIndex}`:''}`;node.append(b);}
  const rh=document.createElement('div');rh.className='resizeHandle';rh.dataset.handle='resize';node.append(rh);const rot=document.createElement('div');rot.className='rotateHandle';rot.dataset.handle='rotate';node.append(rot);
  node.addEventListener('pointerdown',onElementPointerDown);node.addEventListener('dblclick',onElementDoubleClick);host.append(node);
}
function renderText(e,node){
  const d=document.createElement('div');d.className='textEl';d.textContent=(state.textEditing?.id===e.id)?(e.text||''):resolveProjectVariables(e.text||'');const st=e.style||{};
  Object.assign(d.style,{fontFamily:st.font||'Segoe UI',fontSize:(st.fontSize||32)+'px',fontWeight:st.bold?'800':(st.weight||'600'),fontStyle:st.italic?'italic':'normal',color:st.color||COLORS.text,textAlign:st.align||'left',justifyContent:st.align==='center'?'center':st.align==='right'?'flex-end':'flex-start',alignItems:st.vAlign==='middle'?'center':st.vAlign==='bottom'?'flex-end':'flex-start',letterSpacing:(st.letterSpacing||0)+'px',lineHeight:st.lineHeight||1.05,textTransform:st.upper?'uppercase':'none',textShadow:st.shadow?'0 2px 6px #0005':'none',paddingLeft:(st.paddingLeft||0)+'px',paddingRight:(st.paddingRight||0)+'px',paddingTop:(st.paddingTop||0)+'px',paddingBottom:(st.paddingBottom||0)+'px',boxSizing:'border-box'});
  if(state.textEditing?.id===e.id){activateEditableTextNode(d,e,node);}
  node.append(d);
}
function activateEditableTextNode(d,e,node){
  d.contentEditable='true';d.spellcheck=false;d.dataset.liveText='1';
  d.addEventListener('pointerdown',ev=>ev.stopPropagation());
  d.addEventListener('input',()=>{e.text=d.innerText.replace(/\r/g,'');state.dirty=true;state.project.updated_at=new Date().toISOString();setStatus('Editando texto em tempo real...',true);scheduleAutosave();const inp=document.querySelector('[data-prop-key="text"]');if(inp&&inp!==document.activeElement)inp.value=e.text;});
  d.addEventListener('keydown',ev=>{if(ev.key==='Escape'){ev.preventDefault();finishTextEdit(true);}else if((ev.ctrlKey||ev.metaKey)&&ev.key==='Enter'){ev.preventDefault();d.blur();}ev.stopPropagation();});
  d.addEventListener('blur',()=>finishTextEdit(false),{once:true});
  requestAnimationFrame(()=>{if(!d.isConnected)return;d.focus();const sel=window.getSelection(),range=document.createRange();range.selectNodeContents(d);range.collapse(false);sel.removeAllRanges();sel.addRange(range);});
}
function startTextEdit(id){
  const e=findEl(id);if(!e||e.type!=='text'||e.locked)return;state.dragging=null;state.resizing=null;state.rotating=null;state.pendingTextClick=null;state.selected=[id];state.primary=id;state.textEditing={id,before:e.text||''};renderAll();
}
function normalizeCentsText(value){const d=String(value??'').replace(/\D/g,'').slice(-2).padStart(2,'0');return ','+d;}
function finishTextEdit(cancel=false){
  if(!state.textEditing)return;const ed=state.textEditing,e=findEl(ed.id);state.textEditing=null;if(e&&cancel)e.text=ed.before;if(e&&!cancel&&String(e.templateRole||'').toUpperCase()==='PRECO_CENTAVOS')e.text=normalizeCentsText(e.text);if(e&&!cancel&&e.text!==ed.before){markDirty('Texto alterado');snapshot('Texto alterado');}renderAll();
}
function renderShape(e,node){const s=e.style||{},d=document.createElement('div');d.className='shapeEl';Object.assign(d.style,{background:s.fill||'#e8edf5',border:`${s.strokeWidth||0}px solid ${s.stroke||'transparent'}`,borderRadius:e.shape==='circle'?'50%':e.shape==='round'?((s.radius||22)+'px'):'0',boxShadow:s.shadow?'0 6px 14px #1d263644':'none'});if(e.shape==='line'){d.style.height=(s.strokeWidth||4)+'px';d.style.background=s.stroke||COLORS.blue;d.style.marginTop=((e.h||10)/2)+'px';d.style.border='0'}node.append(d);}
function renderImage(e,node){const img=document.createElement('img');img.className='imageEl';img.src=e.url||'';const s=e.style||{};Object.assign(img.style,{objectFit:s.fit||'contain',borderRadius:(s.radius||0)+'px',filter:`brightness(${s.brightness||100}%) contrast(${s.contrast||100}%) saturate(${s.saturate||100}%)`,boxShadow:s.shadow?'0 7px 18px #1620334a':'none'});node.append(img);}
function renderSlot(e,node){const d=document.createElement('div');d.className='slotEl';d.textContent=(e.role||'ZONA')+(e.slotIndex?` ${e.slotIndex}`:'');node.append(d);}
function renderProduct(e,node){
  const p=e.product||{},s={...PRODUCT_CARD_DEFAULT,...(e.style||{})},card=document.createElement('div');card.className='productCard'+(e.variant==='hero'?' hero':'');card.style.background=s.fill;card.style.borderRadius=(s.radius||0)+'px';card.style.boxShadow=s.shadow?'0 4px 14px #1722352e':'none';
  const img=document.createElement('img');img.className='pimg';img.src=p.image_url||e.imageUrl||'';img.style.objectFit=s.imageFit||'contain'; if(!img.src)img.style.display='none';card.append(img);
  const name=document.createElement('div');name.className='pname';name.textContent=p.produto||'PRODUTO';name.style.color=s.nameColor;name.style.fontSize=(s.nameSize||Math.max(12,Math.min(22,(e.w||260)/16)))+'px';card.append(name);
  const priceBox=document.createElement('div');priceBox.className='priceBox';priceBox.style.color=s.priceColor;const pr=money(p.promocao||p.clube||p.varejo||'0,00');priceBox.innerHTML=`<span class="currency">R$</span><span class="price">${pr}</span><span class="unit">${p.unidade||'UN'}</span>`;const price=priceBox.querySelector('.price');price.style.fontSize=(s.priceSize||Math.max(30,Math.min(56,(e.w||260)/4.9)))+'px';card.append(priceBox);
  if(p.clube){const club=document.createElement('div');club.className='club';club.textContent=(p.promocao&&money(p.promocao)!==money(p.clube))?`CLUBE R$ ${money(p.clube)}`:'CLUBE';club.style.background=s.accent||COLORS.blue;card.append(club);}
  node.append(card);
}
function renderGroup(e,node){
  node.style.overflow='visible';for(const child of e.children||[]){const c=clone(child);c.x=(child.x||0);c.y=(child.y||0);renderElement(c,node,false);const last=node.lastElementChild;if(last)last.style.pointerEvents='none';}
}

function toStageCoords(ev){const r=$('#stage').getBoundingClientRect();return {x:(ev.clientX-r.left)/state.zoom,y:(ev.clientY-r.top)/state.zoom};}
function onElementPointerDown(ev){
  ev.stopPropagation();const id=ev.currentTarget.dataset.id;if(state.textEditing)finishTextEdit(false);const e=findEl(id);if(!e)return;const already=state.selected.includes(id);const handle=ev.target.dataset.handle;
  if(ev.shiftKey){if(already)state.selected=state.selected.filter(x=>x!==id);else state.selected.push(id);state.primary=id;}else if(!already){state.selected=[id];state.primary=id;}
  if(e.locked){renderAll();return;}const pos=toStageCoords(ev);
  if(e.type==='text'&&already&&!ev.shiftKey&&!handle){const starts=state.selected.map(sid=>{const se=findEl(sid);return {id:sid,x:se.x||0,y:se.y||0};});state.pendingTextClick={id,start:pos,starts,node:ev.currentTarget,pointerId:ev.pointerId,moved:false};try{ev.currentTarget.setPointerCapture(ev.pointerId);}catch{}return;}
  renderAll();
  if(handle==='resize'){state.resizing={id,start:pos,w:e.w,h:e.h};try{ev.target.setPointerCapture(ev.pointerId);}catch{}}
  else if(handle==='rotate'){const cx=(e.x||0)+(e.w||0)/2,cy=(e.y||0)+(e.h||0)/2;state.rotating={id,cx,cy,startAngle:Math.atan2(pos.y-cy,pos.x-cx),rotation:e.rotation||0};try{ev.target.setPointerCapture(ev.pointerId);}catch{}}
  else {const starts=state.selected.map(sid=>{const se=findEl(sid);return {id:sid,x:se.x||0,y:se.y||0};});state.dragging={start:pos,starts};try{ev.currentTarget.setPointerCapture(ev.pointerId);}catch{}}
  snapshot('Antes de mover');
}
function onElementDoubleClick(ev){ev.preventDefault();ev.stopPropagation();const e=findEl(ev.currentTarget.dataset.id);if(!e)return;if(e.type==='text')startTextEdit(e.id);else if(e.type==='product')setPanel('products');}
function onPointerMove(ev){
  if(state.pendingTextClick){const p=toStageCoords(ev),dx=p.x-state.pendingTextClick.start.x,dy=p.y-state.pendingTextClick.start.y;if(Math.hypot(dx,dy)>4){state.pendingTextClick.moved=true;state.dragging={start:state.pendingTextClick.start,starts:state.pendingTextClick.starts};state.pendingTextClick=null;snapshot('Antes de mover');}}
  if(state.dragging){state.guides=[];const p=toStageCoords(ev),dx=p.x-state.dragging.start.x,dy=p.y-state.dragging.start.y;for(const s of state.dragging.starts){const e=findEl(s.id);if(!e||e.locked)continue;let nx=s.x+dx,ny=s.y+dy;({x:nx,y:ny}=applySnap(e,nx,ny));e.x=nx;e.y=ny;}renderStage();renderLayers();renderProperties();syncTextQuickToolbar();}
  if(state.resizing){const p=toStageCoords(ev),e=findEl(state.resizing.id);if(!e)return;e.w=Math.max(20,state.resizing.w+(p.x-state.resizing.start.x));e.h=Math.max(20,state.resizing.h+(p.y-state.resizing.start.y));renderStage();renderProperties();syncTextQuickToolbar();}
  if(state.rotating){const p=toStageCoords(ev),e=findEl(state.rotating.id);if(!e)return;const a=Math.atan2(p.y-state.rotating.cy,p.x-state.rotating.cx);let deg=state.rotating.rotation+(a-state.rotating.startAngle)*180/Math.PI;if(ev.shiftKey)deg=Math.round(deg/15)*15;e.rotation=Math.round(deg*10)/10;renderStage();renderProperties();syncTextQuickToolbar();}
}
function onPointerUp(){
  if(state.pendingTextClick){const id=state.pendingTextClick.id;state.pendingTextClick=null;startTextEdit(id);return;}
  if(state.dragging||state.resizing||state.rotating){state.dragging=null;state.resizing=null;state.rotating=null;state.guides=[];markDirty('Elemento ajustado');snapshot('Elemento ajustado');renderAll();}
}
function applySnap(e,x,y){
  if(!state.snap)return {x,y};const p=page(),tol=7;let nx=x,ny=y;const ew=e.w||0,eh=e.h||0;
  const targetsX=[0,p.width/2,p.width],targetsY=[0,p.height/2,p.height];
  for(const o of allDisplayElements()){if(o.id===e.id)continue;targetsX.push(o.x||0,(o.x||0)+(o.w||0)/2,(o.x||0)+(o.w||0));targetsY.push(o.y||0,(o.y||0)+(o.h||0)/2,(o.y||0)+(o.h||0));}
  const probesX=[[x,0],[x+ew/2,ew/2],[x+ew,ew]],probesY=[[y,0],[y+eh/2,eh/2],[y+eh,eh]];
  for(const [probe,off] of probesX){const t=targetsX.find(v=>Math.abs(v-probe)<tol);if(t!==undefined){nx=t-off;if(e.id===state.primary)state.guides.push({axis:'v',value:t});break;}}
  for(const [probe,off] of probesY){const t=targetsY.find(v=>Math.abs(v-probe)<tol);if(t!==undefined){ny=t-off;if(e.id===state.primary)state.guides.push({axis:'h',value:t});break;}}
  if(state.grid){nx=Math.round(nx/5)*5;ny=Math.round(ny/5)*5;}return{x:nx,y:ny};
}

function clearSelection(){state.selected=[];state.primary=null;renderAll();}
function selectOne(id){state.selected=[id];state.primary=id;renderAll();}
function addElement(e,targetMaster=false){e.id=e.id||uid(e.type||'el');e.x=e.x??100;e.y=e.y??100;e.w=e.w??240;e.h=e.h??120;e.rotation=e.rotation||0;e.opacity=e.opacity??1;e.z=e.z||Date.now()%100000;(targetMaster?state.project.master.elements:page().elements).push(e);state.selected=[e.id];state.primary=e.id;markDirty('Elemento adicionado');snapshot('Elemento adicionado');renderAll();return e;}
function deleteSelected(){if(!state.selected.length)return;snapshot('Antes de excluir');page().elements=page().elements.filter(e=>!state.selected.includes(e.id));state.project.master.elements=(state.project.master.elements||[]).filter(e=>!state.selected.includes(e.id));state.selected=[];state.primary=null;markDirty('Elemento excluído');snapshot('Elemento excluído');renderAll();}
function duplicateSelected(){if(!state.selected.length)return;snapshot('Antes de duplicar');const created=[];for(const id of state.selected){const e=findEl(id);if(!e)continue;const c=clone(e);c.id=uid(e.type);c.x=(e.x||0)+24;c.y=(e.y||0)+24;c.z=(e.z||1)+1;page().elements.push(c);created.push(c.id);}state.selected=created;state.primary=created[0]||null;markDirty('Duplicado');snapshot('Duplicado');renderAll();}
function lockSelected(){for(const id of state.selected){const e=findEl(id);if(e)e.locked=!e.locked;}markDirty('Bloqueio alterado');snapshot('Bloqueio');renderAll();}
function layerMove(dir){const arr=state.masterEdit?state.project.master.elements:page().elements;if(!state.primary)return;const i=arr.findIndex(e=>e.id===state.primary);if(i<0)return;const ni=dir==='up'?Math.min(arr.length-1,i+1):Math.max(0,i-1);[arr[i],arr[ni]]=[arr[ni],arr[i]];arr.forEach((e,k)=>e.z=k+1);markDirty('Camada alterada');snapshot('Camada');renderAll();}
function bringFront(){for(const id of state.selected){const e=findEl(id);if(e)e.z=999999+Math.random()*1000;}markDirty();snapshot('Frente');renderAll();}
function sendBack(){for(const id of state.selected){const e=findEl(id);if(e)e.z=1;}markDirty();snapshot('Trás');renderAll();}
function alignSelected(mode){if(state.selected.length<2)return;const es=state.selected.map(findEl).filter(Boolean),anchor=es[0];for(const e of es.slice(1)){if(mode==='left')e.x=anchor.x;if(mode==='center')e.x=(anchor.x+anchor.w/2)-e.w/2;if(mode==='right')e.x=anchor.x+anchor.w-e.w;}markDirty('Alinhado');snapshot('Alinhado');renderAll();}
function distributeSelected(axis){if(state.selected.length<3)return toast('Selecione pelo menos 3 elementos.');const es=state.selected.map(findEl).filter(Boolean);es.sort((a,b)=>axis==='h'?(a.x-b.x):(a.y-b.y));if(axis==='h'){const first=es[0],last=es.at(-1),total=es.reduce((a,e)=>a+e.w,0),space=((last.x+last.w)-first.x-total)/(es.length-1);let x=first.x;for(const e of es){e.x=x;x+=e.w+space;}}else{const first=es[0],last=es.at(-1),total=es.reduce((a,e)=>a+e.h,0),space=((last.y+last.h)-first.y-total)/(es.length-1);let y=first.y;for(const e of es){e.y=y;y+=e.h+space;}}markDirty('Distribuição aplicada');snapshot('Distribuir');renderAll();}
function groupSelected(){if(state.selected.length<2)return;const arr=page().elements,chosen=arr.filter(e=>state.selected.includes(e.id));if(chosen.length<2)return;const minX=Math.min(...chosen.map(e=>e.x)),minY=Math.min(...chosen.map(e=>e.y)),maxX=Math.max(...chosen.map(e=>e.x+e.w)),maxY=Math.max(...chosen.map(e=>e.y+e.h));const children=chosen.map(e=>({...clone(e),x:e.x-minX,y:e.y-minY}));page().elements=arr.filter(e=>!state.selected.includes(e.id));const g={id:uid('group'),type:'group',name:'Grupo',x:minX,y:minY,w:maxX-minX,h:maxY-minY,children,z:Date.now()%100000};page().elements.push(g);state.selected=[g.id];state.primary=g.id;markDirty('Agrupado');snapshot('Grupo');renderAll();}
function ungroupSelected(){const id=state.primary,e=findEl(id);if(!e||e.type!=='group')return;page().elements=page().elements.filter(x=>x.id!==id);for(const c of e.children||[]){const n=clone(c);n.id=uid(n.type);n.x=(e.x||0)+(c.x||0);n.y=(e.y||0)+(c.y||0);page().elements.push(n);}state.selected=[];state.primary=null;markDirty('Desagrupado');snapshot('Desagrupar');renderAll();}

function renderProperties(){
  const box=$('#propBody'),e=state.primary?findEl(state.primary):null;$('#selectionLabel').textContent=e?(e.name||e.type):'Nada selecionado';box.innerHTML='';if(!e){box.innerHTML='<div class="hint">Selecione um elemento. O painel muda conforme texto, imagem, forma, produto ou grupo.</div>';return;}
  const group=(title,rows)=>{const g=document.createElement('div');g.className='propGroup';g.innerHTML=`<div class="propGroupTitle">${title}</div>`;for(const r of rows)g.append(r);box.append(g);};
  const row=(label,key,value,type='number',step='1')=>{const d=document.createElement('div');d.className='propRow';const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.type=type;i.value=value??'';i.dataset.propKey=key;if(type==='number')i.step=step;let before=value??'';i.oninput=()=>{let v=type==='number'?Number(i.value):i.value;setPath(e,key,v);state.dirty=true;state.project.updated_at=new Date().toISOString();scheduleAutosave();if(key==='text'){const live=document.querySelector(`.sceneEl[data-id="${CSS.escape(e.id)}"] .textEl`);if(live&&document.activeElement!==live)live.textContent=v;}else renderStage();syncTextQuickToolbar();};i.onchange=()=>{if(key==='text'&&String(e.templateRole||'').toUpperCase()==='PRECO_CENTAVOS'){e.text=normalizeCentsText(i.value);i.value=e.text;renderStage();}markDirty(`${label} alterado`);if(String(before)!==String(i.value))snapshot('Propriedade');};d.append(l,i);return d;};
  group('POSIÇÃO',[row('X','x',Math.round(e.x||0)),row('Y','y',Math.round(e.y||0)),row('Largura','w',Math.round(e.w||0)),row('Altura','h',Math.round(e.h||0)),row('Rotação','rotation',e.rotation||0,'number','.1'),row('Opacidade','opacity',e.opacity??1,'number','.05')]);
  if(e.templateRole){const info=document.createElement('div');info.className='templateBindingInfo';info.innerHTML=`<b>${escapeHTML(e.templateRole)}</b><span>Bloco ${e.slotIndex||'—'}${e.binding?` • ${escapeHTML(e.binding)}`:''}${e.templateConfidence?` • ${Math.round(e.templateConfidence*100)}% confiança`:''}</span>`;box.append(info);}
  if(e.type==='text'){group('TEXTO',[row('Conteúdo','text',e.text||'','text'),row('Fonte','style.font',e.style?.font||'Segoe UI','text'),row('Tamanho','style.fontSize',e.style?.fontSize||32),row('Cor','style.color',e.style?.color||COLORS.text,'color'),row('Espaço','style.letterSpacing',e.style?.letterSpacing||0,'number','.2')]);if(!fontKnown(e.style?.font||'Segoe UI')){const w=document.createElement('div');w.className='fontMissingHint';w.textContent=`Fonte “${e.style?.font}” não encontrada. Importe a mesma fonte usada no Canva para manter o desenho exato.`;box.append(w);}}
  if(e.type==='shape') group('FORMA',[row('Preench.','style.fill',e.style?.fill||'#e8edf5','color'),row('Contorno','style.stroke',e.style?.stroke||'#000000','color'),row('Espessura','style.strokeWidth',e.style?.strokeWidth||0)]);
  if(e.type==='image') group('IMAGEM',[row('URL','url',e.url||'','text'),row('Raio','style.radius',e.style?.radius||0),row('Brilho','style.brightness',e.style?.brightness||100),row('Contraste','style.contrast',e.style?.contrast||100),row('Saturação','style.saturate',e.style?.saturate||100)]);
  if(e.type==='product'){
    const p=e.product||{};group('PRODUTO VIVO',[row('Produto','product.produto',p.produto||'','text'),row('Promo','product.promocao',p.promocao||'','text'),row('Clube','product.clube',p.clube||'','text'),row('Unidade','product.unidade',p.unidade||'UN','text'),row('Preço tam.','style.priceSize',e.style?.priceSize||40),row('Nome tam.','style.nameSize',e.style?.nameSize||15)]);
    group('DADOS MESTRES',[row('Custo','product.custo',p.custo||'','text'),row('Varejo','product.varejo',p.varejo||'','text'),row('CISS','product.codigo_ciss',p.codigo_ciss||'','text')]);
  }
}
function setPath(obj,path,value){const parts=path.split('.');let o=obj;for(let i=0;i<parts.length-1;i++)o=o[parts[i]]||(o[parts[i]]={});o[parts.at(-1)]=value;}

function renderLayers(){const box=$('#layers');box.innerHTML='';const list=[...(state.project.master.elements||[]).map(e=>[e,true]),...page().elements.map(e=>[e,false])].sort((a,b)=>(b[0].z||0)-(a[0].z||0));for(const [e,master] of list){const d=document.createElement('div');d.className='layer'+(state.selected.includes(e.id)?' active':'');d.innerHTML=`<span>${iconFor(e.type)}</span><span>${master?'◆ ':''}${escapeHTML(e.name||labelFor(e))}</span><button title="Visível">${e.hidden?'○':'◉'}</button><button title="Bloqueio">${e.locked?'🔒':'·'}</button>`;d.children[1].onclick=()=>selectOne(e.id);d.children[2].onclick=()=>{e.hidden=!e.hidden;markDirty();renderAll();};d.children[3].onclick=()=>{e.locked=!e.locked;markDirty();renderAll();};box.append(d);}}
function iconFor(t){return ({text:'T',image:'▧',shape:'◇',product:'▤',slot:'⌗',group:'▣'})[t]||'•';}
function labelFor(e){if(e.type==='product')return e.product?.produto||'Produto';if(e.type==='text')return (e.text||'Texto').slice(0,24);return e.type||'Elemento';}
function escapeHTML(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

function renderPages(){const box=$('#pageList');box.innerHTML='';state.project.pages.forEach((p,i)=>{const d=document.createElement('div');d.className='pageRow'+(i===state.pageIndex?' active':'');d.draggable=true;d.dataset.pageIndex=i;d.ondragstart=ev=>ev.dataTransfer.setData('application/x-sr-page',String(i));d.ondragover=ev=>ev.preventDefault();d.ondrop=ev=>{ev.preventDefault();const from=Number(ev.dataTransfer.getData('application/x-sr-page'));if(Number.isInteger(from)&&from!==i){const [moved]=state.project.pages.splice(from,1);state.project.pages.splice(i,0,moved);state.pageIndex=i;markDirty('Páginas reordenadas');snapshot('Reordenar páginas');renderAll();}};d.innerHTML=`<div class="pageThumb" data-page-thumb="${i}">${p.backgroundUrl?`<img src="${p.backgroundUrl}">`:''}</div><div><b>${escapeHTML(p.name||`Página ${i+1}`)}</b><span>${p.width} × ${p.height} • ${p.elements.length} elementos</span></div><button>⋮</button>`;d.onclick=ev=>{if(ev.target.tagName==='BUTTON')return;state.pageIndex=i;clearSelection();renderAll();};d.querySelector('button').onclick=ev=>{ev.stopPropagation();pageMenu(i);};box.append(d);});setTimeout(updatePageThumbnails,25);}
async function updatePageThumbnails(){
  for(let i=0;i<state.project.pages.length;i++){const host=document.querySelector(`[data-page-thumb="${i}"]`);if(!host)continue;try{const pg=state.project.pages[i],scale=Math.min(0.12,110/pg.width,130/pg.height),c=document.createElement('canvas');c.width=Math.max(40,Math.round(pg.width*scale));c.height=Math.max(50,Math.round(pg.height*scale));const ctx=c.getContext('2d');ctx.scale(scale,scale);ctx.fillStyle=pg.backgroundColor||'#fff';ctx.fillRect(0,0,pg.width,pg.height);if(pg.backgroundUrl){try{const bg=await loadImage(pg.backgroundUrl);ctx.drawImage(bg,0,0,pg.width,pg.height);}catch{}}const es=[...(state.project.master.elements||[]),...(pg.elements||[])].filter(e=>!e.hidden).sort((a,b)=>(a.z||0)-(b.z||0));for(const e of es)await drawElement(ctx,e);host.innerHTML='';const img=document.createElement('img');img.src=c.toDataURL('image/jpeg',.72);host.append(img);}catch{}}
}

function pageMenu(i){openModal(`Página ${i+1}`,`<div class="variationGrid"><div class="variation"><strong>DUPLICAR</strong><p>Cria uma cópia completa da página.</p><button id="mDup">Duplicar</button></div><div class="variation"><strong>RENOMEAR</strong><p>Altere o nome da página.</p><button id="mRename">Renomear</button></div><div class="variation"><strong>EXCLUIR</strong><p>Remove a página do projeto.</p><button id="mDelete">Excluir</button></div></div>`);$('#mDup').onclick=()=>{state.pageIndex=i;duplicatePage();closeModal();};$('#mRename').onclick=()=>{const n=prompt('Nome da página:',state.project.pages[i].name);if(n){state.project.pages[i].name=n;markDirty();snapshot('Página renomeada');renderAll();closeModal();}};$('#mDelete').onclick=()=>{if(state.project.pages.length<=1)return toast('O projeto precisa ter ao menos uma página.');state.project.pages.splice(i,1);state.pageIndex=Math.max(0,Math.min(state.pageIndex,state.project.pages.length-1));markDirty();snapshot('Página excluída');renderAll();closeModal();};}
function addPage(){state.project.pages.push(blankPage(`Página ${state.project.pages.length+1}`,page().width,page().height));state.pageIndex=state.project.pages.length-1;markDirty('Página adicionada');snapshot('Página');renderAll();}
function duplicatePage(){const c=clone(page());c.id=uid('page');c.name=(c.name||'Página')+' — cópia';c.elements.forEach(e=>e.id=uid(e.type));state.project.pages.splice(state.pageIndex+1,0,c);state.pageIndex++;markDirty('Página duplicada');snapshot('Duplicar página');renderAll();}
function resizeCurrentPage(w,h,reflow=true){const p=page(),sx=w/p.width,sy=h/p.height;p.width=w;p.height=h;if(reflow){for(const e of p.elements){e.x*=sx;e.y*=sy;e.w*=sx;e.h*=sy;}}markDirty('Formato alterado');snapshot('Magic Resize');renderAll();}
async function magicResize(){const [w,h]=$('#resizePreset').value.split('x').map(Number);resizeCurrentPage(w,h,true);if(page().elements.some(e=>e.type==='product'))await applyAiLayout('balanced');toast('Magic Resize + reorganização inteligente aplicados.','good');aiReview();}

async function loadCampaign(id){if(!id){state.campaignItems=[];state.currentCampaign=null;renderProducts();return;}setStatus('Carregando campanha...');try{const data=await api(`/api/campaign/${id}`);state.currentCampaign=data.campaign;state.campaignItems=data.items||[];state.project.campaignId=Number(id);renderProducts();markDirty('Campanha vinculada');setStatus(`${state.campaignItems.length} produtos • Produto Vivo ativo`);}catch(e){toast(e.message,'bad');}}
function renderProducts(){const q=$('#productSearch').value.trim().toLowerCase(),box=$('#productList');box.innerHTML='';const items=state.campaignItems.filter(p=>!q||`${p.produto} ${p.categoria} ${p.codigo}`.toLowerCase().includes(q));$('#productStats').textContent=`${items.length} de ${state.campaignItems.length} produtos`;
  items.forEach(p=>{const d=document.createElement('div');d.className='productItem';d.draggable=true;d.innerHTML=`${p.image_url?`<img class="productThumb" src="${p.image_url}">`:'<div class="productThumb"></div>'}<div class="productInfo"><strong>${escapeHTML(p.produto)}</strong><span>${escapeHTML(p.categoria||'')} • ${escapeHTML(p.unidade||'UN')}</span></div><div class="productPrice">${money(p.clube||p.promocao||p.varejo)}</div>`;d.onclick=()=>addProduct(p);d.ondragstart=ev=>{ev.dataTransfer.setData('application/x-sr-product',JSON.stringify(p));};box.append(d);});
}
function addProduct(p,rect=null){let r=rect;if(!r){const slot=page().elements.find(e=>e.type==='slot'&&String(e.role||'').toUpperCase()==='PRODUTO');if(slot){r={x:slot.x,y:slot.y,w:slot.w,h:slot.h,role:slot.variant||'normal'};page().elements=page().elements.filter(e=>e.id!==slot.id);}else r={x:90,y:150,w:270,h:300};}return addElement({type:'product',name:p.produto,product:clone(p),imageUrl:p.image_url||'',x:r.x,y:r.y,w:r.w,h:r.h,variant:r.role==='hero'?'hero':'normal',style:{...PRODUCT_CARD_DEFAULT}});}
function campaignProductKey(p){return String(p?.identity_key||p?.codigo||p?.ciss_code||p?.ean||p?.produto||'').trim();}
function smartSlotBoundKey(pg,slot){if(slot?.boundProductKey)return String(slot.boundProductKey);for(const id of [slot?.nameElementId,slot?.reaisElementId,slot?.centsElementId,slot?.priceElementId,slot?.unitElementId,slot?.imageElementId]){const e=smartEl(pg,id);if(e?.boundProductKey)return String(e.boundProductKey);}return '';}
function usedCampaignKeys(exceptPage=null){const used=new Set();state.project.pages.forEach(pg=>{if(pg===exceptPage)return;for(const e of pg.elements||[]){if(e.type==='product'&&e.product)used.add(campaignProductKey(e.product));if(e.boundProductKey)used.add(String(e.boundProductKey));}for(const slot of pg.smartTemplate?.slots||[]){const k=smartSlotBoundKey(pg,slot);if(k)used.add(k);}});used.delete('');return used;}
function productsForSmartPage(pg){const byKey=new Map(state.campaignItems.map(p=>[campaignProductKey(p),p]).filter(([k])=>k));const usedOther=usedCampaignKeys(pg),chosen=[],chosenKeys=new Set();for(const slot of pg.smartTemplate?.slots||[]){const bound=smartSlotBoundKey(pg,slot);const keep=bound&&byKey.get(bound);if(keep&&!chosenKeys.has(bound)){chosen.push(keep);chosenKeys.add(bound);continue;}const next=state.campaignItems.find(p=>{const k=campaignProductKey(p);return k&&!usedOther.has(k)&&!chosenKeys.has(k);});if(next){chosen.push(next);chosenKeys.add(campaignProductKey(next));}else break;}return chosen;}
async function ensureCurrentPageSmartTemplate(){let pg=page();if(pg?.smartTemplate?.slots?.length)return pg;if(!pg||!(pg.elements||[]).length)return pg;if((pg.importMode||'').toUpperCase()==='FAITHFUL')return pg;setStatus('SR IA identificando os campos do modelo antes do preenchimento...',true);const r=await postJSON('/api/template/analyze-zones',{page:clone(pg)});const keepId=pg.id,keepName=pg.name;state.project.pages[state.pageIndex]={...r.page,id:keepId,name:keepName,smartTemplatePending:false};return page();}
async function fillPage(mode='balanced'){
  if(!state.campaignItems.length)return toast('Selecione uma campanha primeiro.');
  snapshot('Antes do preenchimento da página');
  setStatus('SR IA preparando preenchimento da página...',true);
  try{
    let pg=await ensureCurrentPageSmartTemplate();
    if(pg?.smartTemplate?.slots?.length){
      const products=productsForSmartPage(pg);
      if(!products.length)return toast('Todos os produtos desta campanha já foram usados nas outras páginas.','bad');
      const r=fillSmartPage(pg,products,0,{clearUnused:true,autoFit:true});
      markDirty('Campos detectados do Canva preenchidos pela SR IA');snapshot('Preenchimento inteligente da página');renderAll();
      toast(`${r.used} bloco(s) preenchido(s) diretamente nos campos detectados do PPTX: imagem, nome, preço e unidade.`,'good');
      return;
    }
    const selected=state.campaignItems.filter(p=>!usedCampaignKeys(pg).has(campaignProductKey(p))).slice(0,Math.min(12,state.campaignItems.length));
    const r=await postJSON('/api/ai/layout',{page:pg,products:selected.length?selected:state.campaignItems.slice(0,12),mode,campaign:state.currentCampaign||{name:state.project.title}});
    pg.elements=pg.elements.filter(e=>e.type!=='product'&&!(e.type==='slot'&&String(e.role||'').toUpperCase()==='PRODUTO'));for(const item of r.items||[])addProduct(item.product,item.rect);
    markDirty('Página preenchida pela SR IA');snapshot('SR IA layout');renderAll();toast('Nenhum campo de template foi detectado; a SR IA usou o layout automático livre.','good');
  }catch(e){toast('Preenchimento da página: '+e.message,'bad');}
  finally{setStatus('Engine Pro 3.1.1 pronto');}
}
async function syncCampaign(){if(!state.project.campaignId)return toast('Este projeto ainda não está vinculado a uma campanha.');try{const data=await postJSON('/api/sync',{campaignId:state.project.campaignId});const latest=data.items||[],map=new Map(latest.map(p=>[p.identity_key||p.codigo||p.produto,p]));let changes=0;for(const pg of state.project.pages){for(const e of pg.elements){if(e.type!=='product')continue;const old=e.product||{},key=old.identity_key||old.codigo||old.produto,n=map.get(key);if(!n)continue;const fields=['produto','custo','varejo','promocao','clube','unidade','limite','image_path','image_url'];for(const f of fields){if(String(old[f]||'')!==String(n[f]||'')){changes++;break;}}e._pendingProduct=n;}}
    if(!changes)return toast('Encarte Vivo: nenhum dado mudou.','good');openModal('ENCARTE VIVO',`<p>Foram encontradas <b>${changes}</b> atualizações em produtos vinculados.</p><div class="variationGrid"><div class="variation"><strong>ATUALIZAR TUDO</strong><p>Atualiza os dados vinculados. Preços digitados fora do Produto Vivo não são tocados.</p><button id="syncAll">Atualizar</button></div><div class="variation"><strong>REVISAR</strong><p>Mantenha o projeto e revise manualmente os indicadores.</p><button id="syncLater">Agora não</button></div></div>`);$('#syncAll').onclick=()=>{for(const pg of state.project.pages)for(const e of pg.elements)if(e._pendingProduct){e.product=e._pendingProduct;e.imageUrl=e.product.image_url||'';delete e._pendingProduct;}markDirty('Encarte Vivo atualizado');snapshot('Sincronização');closeModal();renderAll();toast('Dados atualizados. Execute a revisão SR IA.','good');};$('#syncLater').onclick=closeModal;
  }catch(e){toast(e.message,'bad');}}


function replaceCampaignKeepingLayout(){
  if(!state.campaignItems.length)return toast('Selecione a nova campanha primeiro.');
  const cards=[];state.project.pages.forEach((pg,pi)=>pg.elements.filter(e=>e.type==='product').forEach(e=>cards.push({e,pi})));
  if(!cards.length)return fillPage('commercial');
  if(!confirm(`Substituir os ${cards.length} produtos atuais pelos produtos da campanha selecionada, mantendo layout e estilos?`))return;
  snapshot('Antes de atualizar campanha');
  let idx=0;for(const c of cards){if(idx>=state.campaignItems.length)break;const p=clone(state.campaignItems[idx++]);c.e.product=p;c.e.name=p.produto;c.e.imageUrl=p.image_url||'';}
  const perPage=Math.max(1,Math.max(...state.project.pages.map(pg=>pg.elements.filter(e=>e.type==='product').length),9));
  const template=clone(state.project.pages[state.project.pages.length-1]);
  while(idx<state.campaignItems.length){const pg=clone(template);pg.id=uid('page');pg.name=`Página ${state.project.pages.length+1}`;pg.elements=pg.elements.filter(e=>e.type!=='product'&&e.type!=='slot');const chunk=state.campaignItems.slice(idx,idx+perPage),rects=localRects(chunk.length,pg.width,pg.height,chunk.length<=7?'hero':'balanced');chunk.forEach((p,i)=>pg.elements.push({id:uid('product'),type:'product',name:p.produto,product:clone(p),imageUrl:p.image_url||'',...rects[i],variant:rects[i].role==='hero'?'hero':'normal',style:{...PRODUCT_CARD_DEFAULT},z:20+i}));state.project.pages.push(pg);idx+=chunk.length;}
  state.project.campaignId=Number($('#campaignSelect').value)||state.project.campaignId;markDirty('Campanha substituída mantendo layout');snapshot('Atualizar campanha');renderAll();toast('Nova campanha aplicada mantendo a estrutura do encarte.','good');aiReview();
}

function pagesByCategory(){
  if(!state.campaignItems.length)return toast('Selecione uma campanha primeiro.');
  if(!confirm('Criar uma página para cada categoria da campanha?'))return;
  snapshot('Antes de páginas por categoria');
  const base=clone(page()),groups={};for(const p of state.campaignItems){const k=(p.categoria||'OFERTAS').toUpperCase();(groups[k]||(groups[k]=[])).push(p);}
  const pages=[];for(const [cat,items] of Object.entries(groups)){const pg=clone(base);pg.id=uid('page');pg.name=cat;pg.elements=pg.elements.filter(e=>e.type!=='product'&&e.type!=='slot'&&!(e.type==='text'&&e.name==='Título Categoria'));pg.elements.push({id:uid('text'),type:'text',name:'Título Categoria',text:cat,x:80,y:55,w:pg.width-160,h:80,style:{font:'Segoe UI',fontSize:48,bold:true,color:COLORS.blue,align:'center',vAlign:'middle'},z:200});const rects=localRects(items.length,pg.width,pg.height,items.length<=7?'hero':'balanced');items.forEach((p,i)=>pg.elements.push({id:uid('product'),type:'product',name:p.produto,product:clone(p),imageUrl:p.image_url||'',...rects[i],variant:rects[i].role==='hero'?'hero':'normal',style:{...PRODUCT_CARD_DEFAULT},z:20+i}));pages.push(pg);}
  state.project.pages=pages.length?pages:state.project.pages;state.pageIndex=0;markDirty('Páginas criadas por categoria');snapshot('Categorias');renderAll();toast(`${pages.length} página(s) criadas por categoria.`,'good');
}
function renderComponents(){const box=$('#componentList');if(!box)return;box.innerHTML='';for(const c of state.components){const d=document.createElement('div');d.className='recent';d.textContent=c.name;d.onclick=()=>insertComponent(c);box.append(d);}if(!state.components.length)box.innerHTML='<div class="hint">Selecione um elemento ou grupo e salve como componente reutilizável.</div>';}
function saveComponent(){if(!state.selected.length)return toast('Selecione um elemento ou grupo.');const name=prompt('Nome do componente:','Componente SR');if(!name)return;let base;if(state.selected.length===1)base=clone(findEl(state.primary));else{const chosen=state.selected.map(findEl).filter(Boolean),minX=Math.min(...chosen.map(e=>e.x)),minY=Math.min(...chosen.map(e=>e.y)),maxX=Math.max(...chosen.map(e=>e.x+e.w)),maxY=Math.max(...chosen.map(e=>e.y+e.h));base={type:'group',name, x:0,y:0,w:maxX-minX,h:maxY-minY,children:chosen.map(e=>({...clone(e),x:e.x-minX,y:e.y-minY}))};}base.id=null;state.components.push({id:uid('component'),name,element:base});if(state.components.length>40)state.components=state.components.slice(-40);localStorage.setItem('sr3_components',JSON.stringify(state.components));renderComponents();toast('Componente salvo.','good');}
function insertComponent(c){const e=clone(c.element);const reseed=x=>{x.id=uid(x.type||'el');for(const ch of x.children||[])reseed(ch);};reseed(e);e.x=120;e.y=160;addElement(e);}

function applyStarterTemplate(id){snapshot('Antes do template');const p=page();p.backgroundUrl='';p.background_path='';p.backgroundColor=id==='quinta'?'#3d0909':id==='verde'?'#eef8e8':id==='clube'?'#edf4ff':'#fff';p.elements=[];
  if(id==='blank'){markDirty();snapshot('Template em branco');renderAll();return;}
  addElement({type:'text',name:'Título',text:id==='quinta'?'QUINTA FILÉ':id==='verde'?'TERÇA VERDE':id==='clube'?'OFERTAS CLUBE':'OFERTAS',x:70,y:45,w:940,h:90,style:{font:'Segoe UI',fontSize:58,bold:true,color:id==='quinta'?'#fff':COLORS.navy,align:'center',vAlign:'middle'}});
  const n=id==='grid9'?9:7,mode=id==='hero6'?'hero':'balanced',rects=localRects(n,p.width,p.height,mode);for(let i=0;i<n;i++){const r=rects[i];addElement({type:'slot',name:`Produto ${i+1}`,role:'PRODUTO',slotIndex:i+1,...r,z:2});}
  addElement({type:'text',name:'Validade',text:'OFERTAS VÁLIDAS ENQUANTO DURAREM OS ESTOQUES',x:60,y:p.height-55,w:p.width-120,h:28,style:{fontSize:14,bold:true,color:id==='quinta'?'#fff':COLORS.navy,align:'center'}});
  markDirty('Template aplicado');snapshot('Template aplicado');renderAll();
}
function localRects(n,w,h,mode='balanced'){const m=45,g=22,top=165,usable=h-top-85,out=[];if(mode==='hero'&&n>2){const hh=usable*.34;out.push({x:m,y:top,w:w-2*m,h:hh,role:'hero'});const rest=n-1,cols=3,rows=Math.ceil(rest/cols),cw=(w-2*m-g*(cols-1))/cols,ch=(usable-hh-g-g*(rows-1))/rows;for(let i=0;i<rest;i++){let c=i%cols,r=Math.floor(i/cols);out.push({x:m+c*(cw+g),y:top+hh+g+r*(ch+g),w:cw,h:ch});}return out;}const cols=n<=4?2:3,rows=Math.ceil(n/cols),cw=(w-2*m-g*(cols-1))/cols,ch=(usable-g*(rows-1))/rows;for(let i=0;i<n;i++){let c=i%cols,r=Math.floor(i/cols);out.push({x:m+c*(cw+g),y:top+r*(ch+g),w:cw,h:ch});}return out;}

function addText(kind){const map={title:{text:'TÍTULO',w:620,h:90,size:58,bold:true},subtitle:{text:'Subtítulo',w:520,h:70,size:34,bold:true},body:{text:'Digite seu texto',w:420,h:90,size:24,bold:false},price:{text:'R$ 19,99',w:300,h:100,size:62,bold:true}};const v=map[kind]||map.body;addElement({type:'text',name:'Texto',text:v.text,x:180,y:180,w:v.w,h:v.h,style:{font:'Segoe UI',fontSize:v.size,bold:v.bold,color:kind==='price'?COLORS.blue:COLORS.text,align:'center',vAlign:'middle'}});}
function addShape(shape){addElement({type:'shape',name:'Forma',shape,x:180,y:180,w:shape==='line'?320:240,h:shape==='line'?18:180,style:{fill:'#e8edf5',stroke:COLORS.blue,strokeWidth:shape==='line'?5:0,radius:22,shadow:false}});}
function addSlot(){const role=prompt('Tipo da zona: PRODUTO, IMAGEM, PREÇO, NOME, UNIDADE, CLUBE, VALIDADE','PRODUTO');if(!role)return;addElement({type:'slot',name:`Zona ${role}`,role:role.toUpperCase(),x:150,y:200,w:280,h:220});}
function autoSlots(){const raw=prompt('Quantos espaços de produto este modelo deve ter?','9');const n=clamp(Number(raw)||9,1,30);snapshot('Antes das zonas');page().elements=page().elements.filter(e=>!(e.type==='slot'&&String(e.role||'').toUpperCase()==='PRODUTO'));const rects=localRects(n,page().width,page().height,n<=7?'hero':'balanced');rects.forEach((r,i)=>page().elements.push({id:uid('slot'),type:'slot',name:`Produto ${i+1}`,role:'PRODUTO',slotIndex:i+1,...r,z:2}));markDirty('Zonas inteligentes criadas');snapshot('Zonas automáticas');renderAll();toast(`${n} zonas de Produto Vivo criadas sobre o modelo fiel.`,'good');}

function smartTemplateSummaryText(s){
  if(!s||!s.mapped)return 'Nenhum bloco comercial foi reconhecido automaticamente nesta página.';
  const r=s.roles||{};return `${s.slotCount||0} bloco(s) de produto • ${r.NOME||0} nomes • ${r.IMAGEM||0} áreas de imagem${r.IMAGEM_INFERIDA?` + ${r.IMAGEM_INFERIDA} inferida(s)`:''} • ${r.PRECO_REAIS||0} caixas de reais • ${r.PRECO_CENTAVOS||0} caixas de centavos • confiança ${Math.round((s.confidence||0)*100)}%`;
}
function showSmartTemplateSummary(s,title='MODELO ENTENDIDO PELA SR IA'){
  if(!s)return;
  openModal(title,`<div class="aiCard"><strong>MAPEAMENTO INTELIGENTE</strong><span>${escapeHTML(smartTemplateSummaryText(s))}</span></div><p class="hint">O preço dividido foi reconhecido como <b>REAIS</b> + <b>,CENTAVOS</b>. A vírgula pertence permanentemente à caixa dos centavos.</p><div class="variationGrid"><div class="variation"><strong>REVISAR NO CANVAS</strong><p>Clique em qualquer elemento mapeado para ver sua função e o número do bloco.</p><button id="smartReviewClose">REVISAR</button></div><div class="variation"><strong>PREENCHER CAMPANHA</strong><p>Usa os produtos da campanha atual sem desmontar o design do Canva.</p><button class="primary" id="smartFillNow">PREENCHER</button></div></div>`);
  $('#smartReviewClose').onclick=closeModal;$('#smartFillNow').onclick=()=>{closeModal();fillSmartTemplate();};
}
async function analyzeTemplateZones(){
  if(!page()?.elements?.length)return toast('Esta página não possui elementos editáveis para analisar. Importe o PPTX como EDITÁVEL TOTAL ou HÍBRIDO.');
  setStatus('SR IA analisando estrutura do modelo...',true);
  try{const r=await postJSON('/api/template/analyze-zones',{page:page()});const oldId=page().id,oldName=page().name;state.project.pages[state.pageIndex]={...r.page,id:oldId,name:oldName};markDirty('Modelo analisado pela SR IA');snapshot('Mapeamento inteligente');renderAll();showSmartTemplateSummary(r.smartTemplate);}catch(e){toast(e.message,'bad');}finally{setStatus('Engine Pro 3.1.1 pronto');}
}
function splitSmartPrice(value){const m=money(value||'0,00').match(/(-?\d+),([0-9]{2})/);return m?{reais:m[1],centavos:','+m[2],completo:m[1]+','+m[2]}:{reais:'0',centavos:',00',completo:'0,00'};}
function smartEl(pg,id){return id?(pg.elements||[]).find(e=>e.id===id):null;}
function setSmartElementVisibility(e,visible){if(!e)return;e.hidden=!visible;}
function clearSmartSlot(pg,slot){for(const id of [slot.nameElementId,slot.reaisElementId,slot.centsElementId,slot.priceElementId,slot.currencyElementId,slot.unitElementId,slot.imageElementId]){const e=smartEl(pg,id);if(e)setSmartElementVisibility(e,false);}slot.boundProductKey='';slot.boundProductName='';}
function fillSmartPage(pg,products,startIndex=0,options={}){
  const smart=pg.smartTemplate;if(!smart?.slots?.length)return {used:0,next:startIndex};let idx=startIndex,used=0;
  const autoFit=options.autoFit!==false,clearUnused=options.clearUnused!==false;
  // Remove apenas as imagens criadas anteriormente pela IA; preserva o design original do Canva.
  pg.elements=(pg.elements||[]).filter(e=>!e.smartTemplateGenerated);
  for(const slot of smart.slots){
    if(idx>=products.length){if(clearUnused)clearSmartSlot(pg,slot);continue;}
    const p=clone(products[idx++]);used++;const key=campaignProductKey(p);slot.boundProductKey=key;slot.boundProductName=p.produto||'';slot.productSnapshot=clone(p);
    const pr=splitSmartPrice(p.promocao||p.clube||p.varejo||'0,00');
    const name=smartEl(pg,slot.nameElementId);if(name){setSmartElementVisibility(name,true);name.text=p.produto||'';name.boundProductKey=key;if(autoFit)autoFitElement(name);}
    const reais=smartEl(pg,slot.reaisElementId);if(reais){setSmartElementVisibility(reais,true);reais.text=pr.reais;reais.boundProductKey=key;if(autoFit)autoFitElement(reais);}
    const cents=smartEl(pg,slot.centsElementId);if(cents){setSmartElementVisibility(cents,true);cents.text=pr.centavos;cents.persistentPrefix=',';cents.boundProductKey=key;if(autoFit)autoFitElement(cents);}
    const full=smartEl(pg,slot.priceElementId);if(full){setSmartElementVisibility(full,true);full.text=pr.completo;full.boundProductKey=key;if(autoFit)autoFitElement(full);}
    const cur=smartEl(pg,slot.currencyElementId);if(cur){setSmartElementVisibility(cur,true);cur.text='R$';cur.boundProductKey=key;}
    const unit=smartEl(pg,slot.unitElementId);if(unit){setSmartElementVisibility(unit,true);unit.text=p.unidade||'UN';unit.boundProductKey=key;if(autoFit)autoFitElement(unit);}
    const ir=slot.imageRect||null,existing=smartEl(pg,slot.imageElementId),src=p.image_url||'';
    if(src&&ir){
      if(existing?.type==='image'){
        setSmartElementVisibility(existing,true);if(!existing.templateOriginal){existing.templateOriginal={url:existing.url||'',asset_path:existing.asset_path||''};}
        existing.url=src;existing.asset_path=p.image_path||'';existing.boundProductKey=key;existing.style={...(existing.style||{}),fit:'contain'};
      }else{
        const zBase=Math.max(2,Math.min(name?.z||80,reais?.z||90)-1);pg.elements.push({id:uid('image'),type:'image',name:`Imagem • ${p.produto||'Produto'}`,url:src,asset_path:p.image_path||'',x:ir.x,y:ir.y,w:ir.w,h:ir.h,z:zBase,rotation:0,opacity:1,templateRole:'IMAGEM',slotIndex:slot.index,boundProductKey:key,smartTemplateGenerated:true,style:{fit:'contain',radius:0,brightness:100,contrast:100,saturate:100,shadow:false}});
      }
    }else if(existing?.type==='image'){
      // Nunca deixa a foto antiga do Canva representar um produto novo sem imagem aprovada.
      setSmartElementVisibility(existing,false);existing.boundProductKey=key;
    }
  }
  return {used,next:idx};
}
async function ensureAllSmartTemplates(){let mapped=0;for(let i=0;i<state.project.pages.length;i++){const pg=state.project.pages[i];if(pg.smartTemplate?.slots?.length){mapped++;continue;}if((pg.importMode||'').toUpperCase()==='FAITHFUL'||!(pg.elements||[]).length)continue;try{const r=await postJSON('/api/template/analyze-zones',{page:clone(pg)});state.project.pages[i]={...r.page,id:pg.id,name:pg.name,smartTemplatePending:false};if(r.smartTemplate?.slots?.length)mapped++;}catch(err){console.warn('Mapeamento automático página',i+1,err);}}return mapped;}
function cloneMappedTemplatePage(source){const pg=clone(source),idMap=new Map();pg.id=uid('page');pg.name=`${source.name||'Página'} — continuação`;pg.elements=(pg.elements||[]).filter(e=>!e.smartTemplateGenerated).map(e=>{const old=e.id,n={...e,id:uid(e.type||'el')};idMap.set(old,n.id);delete n.boundProductKey;n.hidden=false;return n;});if(pg.smartTemplate){pg.smartTemplate=clone(pg.smartTemplate);for(const slot of pg.smartTemplate.slots||[]){for(const f of ['nameElementId','reaisElementId','centsElementId','priceElementId','currencyElementId','unitElementId','imageElementId'])if(slot[f]&&idMap.has(slot[f]))slot[f]=idMap.get(slot[f]);slot.boundProductKey='';slot.boundProductName='';delete slot.productSnapshot;}}return pg;}
function ensureSmartTemplateCapacity(mapped,productCount){let capacity=mapped.reduce((n,pg)=>n+(pg.smartTemplate?.slots?.length||0),0);if(capacity>=productCount||!mapped.length)return mapped;const base=[...mapped].sort((a,b)=>(b.smartTemplate?.slots?.length||0)-(a.smartTemplate?.slots?.length||0))[0];const per=Math.max(1,base.smartTemplate?.slots?.length||0);while(capacity<productCount){const c=cloneMappedTemplatePage(base);state.project.pages.push(c);mapped.push(c);capacity+=per;}return mapped;}
async function fillSmartTemplate(){
  if(!state.campaignItems.length)return toast('Selecione uma campanha antes de preencher o template.');
  snapshot('Antes de preencher template inteligente');setStatus('SR IA detectando campos e preenchendo o encarte completo...',true);
  try{
    const mappedCount=await ensureAllSmartTemplates();let mapped=state.project.pages.filter(pg=>pg.smartTemplate?.slots?.length);if(!mappedCount||!mapped.length)return toast('Nenhum campo comercial foi detectado. Importe o PPTX como EDITÁVEL TOTAL ou HÍBRIDO.','bad');
    const pagesBeforeCapacity=state.project.pages.length;mapped=ensureSmartTemplateCapacity(mapped,state.campaignItems.length);
    let idx=0,total=0;for(const pg of mapped){const r=fillSmartPage(pg,state.campaignItems,idx,{clearUnused:true,autoFit:true});idx=r.next;total+=r.used;if(idx>=state.campaignItems.length){for(const rest of mapped.slice(mapped.indexOf(pg)+1))fillSmartPage(rest,[],0,{clearUnused:true});break;}}
    markDirty('Encarte completo preenchido nos campos detectados');snapshot('Template inteligente preenchido');renderAll();const extra=Math.max(0,state.project.pages.length-pagesBeforeCapacity);toast(`${total} produto(s) distribuído(s) automaticamente em ${mapped.length} página(s)${extra?` • ${extra} página(s) de continuação criada(s)`:''}, usando os campos detectados do Canva.`,'good');
  }catch(e){toast('Preenchimento do template: '+e.message,'bad');}
  finally{setStatus('Engine Pro 3.1.1 pronto');}
}

function addBrandTitle(){addElement({type:'text',name:'Título SR',text:'OFERTAS SR',x:90,y:55,w:900,h:90,style:{font:'Segoe UI',fontSize:58,bold:true,color:COLORS.blue,align:'center',vAlign:'middle',upper:true}});}
function addSmartBadge(){addElement({type:'shape',name:'Selo Clube',shape:'round',x:760,y:80,w:230,h:86,style:{fill:COLORS.blue,radius:20,shadow:true}});addElement({type:'text',name:'Texto Clube',text:'CLUBE',x:790,y:95,w:170,h:55,style:{fontSize:34,bold:true,color:'#fff',align:'center',vAlign:'middle'}});}
function addValidity(){addElement({type:'text',name:'Validade',text:'OFERTAS VÁLIDAS DE __/__/__ A __/__/__',x:100,y:page().height-80,w:page().width-200,h:35,style:{fontSize:16,bold:true,color:COLORS.navy,align:'center',vAlign:'middle'}});}
function addFooter(){addElement({type:'shape',name:'Rodapé',shape:'rect',x:0,y:page().height-60,w:page().width,h:60,style:{fill:COLORS.navy}});addElement({type:'text',name:'Rodapé SR',text:'SR • Supermercado Rodrigues',x:30,y:page().height-52,w:page().width-60,h:42,style:{fontSize:16,bold:true,color:'#fff',align:'center',vAlign:'middle'}});}
function moveToMaster(){if(!state.selected.length)return;const moving=page().elements.filter(e=>state.selected.includes(e.id));page().elements=page().elements.filter(e=>!state.selected.includes(e.id));state.project.master.elements.push(...moving);markDirty('Movido para Página Mestre');snapshot('Master');renderAll();}
function toggleMaster(){state.masterEdit=!state.masterEdit;toast(state.masterEdit?'Editando Página Mestre':'Voltando à página normal','good');clearSelection();}

async function uploadFile(file,path){
  if(!file)throw new Error('Nenhum arquivo selecionado.');
  if(file.size===0)throw new Error('O arquivo selecionado está vazio.');
  const sep=path.includes('?')?'&':'?';const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),8*60*1000);
  try{
    const body=await file.arrayBuffer();
    return await api(`${path}${sep}name=${encodeURIComponent(file.name)}`,{method:'POST',headers:{'Content-Type':'application/octet-stream','X-SR-File-Size':String(file.size)},body,signal:controller.signal});
  }catch(e){
    if(e?.name==='AbortError')throw new Error('A importação excedeu o tempo limite. Feche outros PowerPoints e tente novamente.');
    throw e;
  }finally{clearTimeout(timer);}
}
function addImportedImageResult(r,name='Imagem'){
  addElement({type:'image',name:name||r.name||'Imagem',url:r.url,asset_path:r.asset_path,x:180,y:180,w:360,h:360,style:{fit:'contain',radius:0,brightness:100,contrast:100,saturate:100,shadow:false}});
  toast('Imagem adicionada.','good');
}
async function uploadImage(file){setStatus(`Importando imagem ${file?.name||''}...`,true);try{const r=await uploadFile(file,'/api/upload');addImportedImageResult(r,file.name);}catch(e){toast('Falha ao importar imagem: '+e.message,'bad');}finally{setStatus('Engine Pro 3.1.1 pronto');}}
async function nativePick(kind){
  try{return await api(`/api/native-file-dialog?kind=${encodeURIComponent(kind)}`);}catch(e){console.warn('Seletor nativo indisponível',e);throw e;}
}
async function startImageImport(){
  setStatus('Abrindo seletor de imagens do Windows...',true);
  try{
    const pick=await nativePick('image');if(pick?.cancelled){setStatus('Engine Pro 3.1.1 pronto');return;}
    setStatus(`Importando ${pick.name}...`,true);
    const r=await postJSON('/api/import-image-path',{path:pick.path});addImportedImageResult(r,pick.name);
  }catch(e){
    console.warn('Importação nativa de imagem',e);toast('O seletor nativo não respondeu. Abrindo seletor alternativo...','bad');setTimeout(()=>$('#imageInput').click(),80);
  }finally{setStatus('Engine Pro 3.1.1 pronto');}
}
function showTemplateModeChooser(source){
  const isNative=!!source?.path;const name=source?.name||'modelo.pptx';const ext=(name.split('.').pop()||'').toLowerCase();
  if(ext!=='pptx')return isNative?doImportTemplatePath(source,'FAITHFUL'):doImportTemplate(source,'FAITHFUL');
  openModal('IMPORTAR PPTX / CANVA',`<p class="hint">Escolha como o SR Studio deve tratar o modelo. Para editar livremente, use <b>EDITÁVEL TOTAL</b>.</p><div class="variationGrid"><div class="variation"><strong>EDITÁVEL TOTAL</strong><p>Desagrupa o PPTX. Textos, fotos, formas e vetores entram como objetos separados da Scene Graph.</p><button class="primary" data-import-mode="EDITABLE">IMPORTAR EDITÁVEL</button></div><div class="variation"><strong>HÍBRIDO</strong><p>Mantém partes complexas no fundo e extrai os elementos principais para edição.</p><button data-import-mode="HYBRID">IMPORTAR HÍBRIDO</button></div><div class="variation"><strong>FIEL</strong><p>Preserva a página inteira como uma única base visual.</p><button data-import-mode="FAITHFUL">IMPORTAR FIEL</button></div></div>`);
  $$('[data-import-mode]').forEach(b=>b.onclick=()=>{const mode=b.dataset.importMode;closeModal();isNative?doImportTemplatePath(source,mode):doImportTemplate(source,mode);});
}
async function startTemplateImport(){
  setStatus('Abrindo seletor de modelos do Windows...',true);
  try{const pick=await nativePick('template');if(pick?.cancelled){setStatus('Engine Pro 3.1.1 pronto');return;}showTemplateModeChooser(pick);}
  catch(e){console.warn('Seletor nativo de modelo',e);toast('O seletor nativo não respondeu. Abrindo seletor alternativo...','bad');setTimeout(()=>$('#templateInput').click(),80);}
}
async function importTemplate(file){showTemplateModeChooser(file);}
async function analyzeImportedTemplatesInBackground(){
  const indexes=state.project.pages.map((pg,i)=>({pg,i})).filter(x=>x.pg.smartTemplatePending||((x.pg.importMode||'')!=='FAITHFUL'&&(x.pg.elements||[]).length));
  if(!indexes.length)return;
  setStatus('Modelo importado • SR IA analisando zonas em segundo plano...',true);
  let mapped=0,slots=0;
  for(const item of indexes){
    try{
      const r=await postJSON('/api/template/analyze-zones',{page:clone(item.pg)});
      const current=state.project.pages[item.i];
      if(!current)continue;
      const keepId=current.id,keepName=current.name;
      state.project.pages[item.i]={...r.page,id:keepId,name:keepName,smartTemplatePending:false};
      if(r.smartTemplate?.mapped){mapped++;slots+=Number(r.smartTemplate.slotCount||0);}
    }catch(err){console.warn('Template Intelligence página',item.i+1,err);state.project.pages[item.i].smartTemplatePending=false;}
    await new Promise(r=>setTimeout(r,35));
  }
  if(mapped){markDirty('Template analisado pela SR IA');renderAll();toast(`SR IA mapeou ${slots} bloco(s) em ${mapped} página(s).`,'good');}
  setStatus('Engine Pro 3.1.1 pronto');
}

function applyImportedTemplateResult(r,mode='EDITABLE'){
  if(!r.pages?.length)throw new Error('Nenhuma página importada.');
  snapshot('Antes da importação');
  state.project.pages=r.pages.map((pg,i)=>({id:uid('page'),name:pg.name||`Página ${i+1}`,width:pg.width||1080,height:pg.height||1350,backgroundColor:pg.backgroundColor||'#fff',backgroundUrl:pg.backgroundUrl||'',background_path:pg.background_path||'',elements:pg.elements||[],importMode:pg.importMode||mode,pptxEditable:!!pg.pptxEditable,smartTemplate:pg.smartTemplate||null,smartTemplatePending:!!pg.smartTemplatePending}));
  state.pageIndex=0;state.selected=[];const mappedFonts=autoMapProjectFonts();markDirty('Modelo importado');snapshot('Importação de modelo');renderAll();
  const n=Number(r.extractedElements||0),labels={EDITABLE:'editável total',HYBRID:'híbrido',FAITHFUL:'fiel'};
  if(mode==='EDITABLE')toast(`${r.pages.length} página(s) • ${n} elemento(s) separados e editáveis.`, 'good');else toast(`${r.pages.length} página(s) importada(s) em modo ${labels[mode]||mode}.`, 'good');
  const missing=[...new Set(state.project.pages.flatMap(pg=>(pg.elements||[]).filter(e=>e.type==='text'&&e.style?.font&&!fontKnown(e.style.font)).map(e=>e.style.font)))];
  if(missing.length)toast(`${missing.length} fonte(s) do modelo não estão disponíveis. Abra Texto → Fontes para importar.`, 'bad');else if(mappedFonts)toast(`${mappedFonts} texto(s) tiveram a fonte equivalente vinculada automaticamente.`,'good');
  setStatus('Modelo importado • preparando SR IA...',true);setTimeout(()=>analyzeImportedTemplatesInBackground(),500);
}
async function doImportTemplatePath(source,mode='EDITABLE'){
  const labels={EDITABLE:'editável total',HYBRID:'híbrido',FAITHFUL:'fiel'};setStatus(`Importando ${source.name} pelo Windows em modo ${labels[mode]||mode}...`,true);
  try{const r=await postJSON('/api/import-template-path',{path:source.path,mode});applyImportedTemplateResult(r,mode);}
  catch(e){console.error('Importação nativa',e);setStatus('Falha na importação',true);if(mode!=='FAITHFUL'&&String(source.name||'').toLowerCase().endsWith('.pptx')){openModal('NÃO FOI POSSÍVEL IMPORTAR O PPTX',`<p class="hint">${escapeHTML(e.message)}</p><div class="inline"><button id="retryNative">TENTAR NOVAMENTE</button><button class="primary grow" id="retryNativeFaithful">ABRIR EM MODO FIEL</button></div>`);$('#retryNative').onclick=()=>{closeModal();setTimeout(()=>doImportTemplatePath(source,mode),150);};$('#retryNativeFaithful').onclick=()=>{closeModal();setTimeout(()=>doImportTemplatePath(source,'FAITHFUL'),150);};}else toast('Importação: '+e.message,'bad');}
  finally{if($('#statusText')?.textContent?.startsWith('Importando'))setStatus('Engine Pro 3.1.1 pronto');}
}
async function doImportTemplate(file,mode='EDITABLE'){
  const labels={EDITABLE:'editável total',HYBRID:'híbrido',FAITHFUL:'fiel'};setStatus(`Importando ${file.name} em modo ${labels[mode]||mode}...`,true);
  try{
    const r=await uploadFile(file,`/api/import-template?mode=${encodeURIComponent(mode)}`);
    applyImportedTemplateResult(r,mode);
  }catch(e){
    console.error('Importação',e);
    setStatus('Falha na importação',true);
    if(mode!=='FAITHFUL'&&file.name.toLowerCase().endsWith('.pptx')){
      openModal('NÃO FOI POSSÍVEL IMPORTAR O PPTX',`<p class="hint">${escapeHTML(e.message)}</p><p>O arquivo não foi descartado. Você pode tentar novamente no modo editável ou abrir imediatamente em <b>Modo Fiel</b> para continuar trabalhando enquanto verificamos algum elemento incompatível do PowerPoint.</p><div class="inline"><button id="retryEditable">TENTAR NOVAMENTE</button><button class="primary grow" id="retryFaithful">ABRIR EM MODO FIEL</button></div>`);
      $('#retryEditable').onclick=()=>{closeModal();setTimeout(()=>doImportTemplate(file,mode),150);};
      $('#retryFaithful').onclick=()=>{closeModal();setTimeout(()=>doImportTemplate(file,'FAITHFUL'),150);};
    }else toast('Importação: '+e.message,'bad');
  }finally{if($('#statusText')?.textContent?.startsWith('Importando'))setStatus('Engine Pro 3.1.1 pronto');}
}
async function searchProductImage(){const e=findEl(state.primary);if(!e||e.type!=='product')return toast('Selecione um card de Produto Vivo.');setStatus('SR IA procurando packshots...',true);try{const r=await postJSON('/api/image/search',{product:e.product,maxResults:8});const cs=r.candidates||[];if(!cs.length){toast('Nenhuma imagem adequada encontrada.','bad');return;}openModal('IMAGENS SUGERIDAS — APROVAÇÃO MANUAL',`<p class="hint">A SR IA classifica os candidatos, mas nenhuma imagem é aprovada automaticamente.</p><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:9px">${cs.map((c,i)=>`<div class="variation"><img src="${c.url}" style="width:100%;height:150px;object-fit:contain;background:#f6f7f9;border-radius:7px"><strong>${Math.round(c.score||0)}% • ${escapeHTML(c.confidence||'')}</strong><p>NOME ${Math.round(c.name_match||0)}% • OCR ${c.ocr_score==null?'—':Math.round(c.ocr_score)+'%'} • VISUAL ${Math.round(c.visual_score||0)}%</p><p>${escapeHTML(c.source_name||'Fonte')}</p><button data-candidate="${i}">APROVAR</button></div>`).join('')}</div>`);$$('[data-candidate]').forEach(b=>b.onclick=async()=>{const c=cs[Number(b.dataset.candidate)];try{const a=await postJSON('/api/image/approve',{product:e.product,candidate:c});e.product.image_path=a.official_path;e.product.image_url=a.url;e.imageUrl=a.url;for(const pg of state.project.pages)for(const pe of pg.elements)if(pe.type==='product'&&pe.id!==e.id&&pe.product?.identity_key&&pe.product.identity_key===e.product.identity_key){pe.product.image_path=a.official_path;pe.product.image_url=a.url;pe.imageUrl=a.url;}markDirty('Imagem oficial aprovada');snapshot('Aprovação de imagem');closeModal();renderAll();toast('Imagem aprovada e vinculada ao Produto Vivo.','good');}catch(err){toast(err.message,'bad');}});}catch(err){toast('Busca de imagens: '+err.message,'bad');}finally{setStatus('Engine Pro 3.1.1 pronto');}}

function selectedImageSource(e){if(!e)return null;if(e.type==='image'&&e.asset_path)return {path:e.asset_path,url:e.url||'',kind:'image'};if(e.type==='product'&&e.product?.image_path)return {path:e.product.image_path,url:e.product.image_url||e.imageUrl||'',kind:'product'};return null;}
function applyRemovedBackground(e,r,original){if(e.type==='image'){e._backgroundOriginal=e._backgroundOriginal||original;e.asset_path=r.asset_path;e.url=r.url;e.backgroundAI=r.analysis||{};}else if(e.type==='product'){e._backgroundOriginal=e._backgroundOriginal||original;e.product=e.product||{};e.product.image_path=r.asset_path;e.product.image_url=r.url;e.imageUrl=r.url;e.backgroundAI=r.analysis||{};}}
function restoreBackgroundOriginal(e){const o=e?e._backgroundOriginal:null;if(!e||!o)return;if(e.type==='image'){e.asset_path=o.path;e.url=o.url;}else if(e.type==='product'){e.product.image_path=o.path;e.product.image_url=o.url;e.imageUrl=o.url;}delete e.backgroundAI;delete e._backgroundOriginal;markDirty('Imagem original restaurada');snapshot('Restaurar fundo');renderAll();toast('Imagem original restaurada.','good');}
async function runRemoveBg(mode){const e=findEl(state.primary),src=selectedImageSource(e);if(!src)return toast('Selecione uma imagem ou um Produto Vivo com imagem.');const shadow=$('#bgKeepShadow')?.checked!==false,feather=Number($('#bgFeather')?.value||1.4);const original={path:src.path,url:src.url};setStatus(`SR IA recortando em modo ${mode.toLowerCase()}...`,true);try{const r=await postJSON('/api/image/remove-bg',{asset_path:src.path,mode,preserveShadow:shadow,feather});applyRemovedBackground(e,r,original);markDirty('Fundo removido pela SR IA');snapshot('Remover fundo IA');renderAll();const engine=r.analysis?.engine||'SR Background AI',coverage=Math.round((r.analysis?.coverage||0)*100);openModal('RECORTE IA CONCLUÍDO',`<div class="bgCompare"><div><b>ANTES</b><img src="${original.url}"></div><div><b>DEPOIS</b><img src="${r.url}"></div></div><p class="hint">Motor: <b>${escapeHTML(engine)}</b>${coverage?` • objeto preservado: ${coverage}% da área`:''}. O arquivo original continua preservado para restauração.</p><div class="inline"><button id="bgRestore">RESTAURAR ORIGINAL</button><button class="primary grow" id="bgKeep">MANTER RECORTE</button></div>`);$('#bgRestore').onclick=()=>{closeModal();restoreBackgroundOriginal(e);};$('#bgKeep').onclick=()=>{delete e._backgroundOriginal;closeModal();toast('Recorte mantido.','good');};}catch(err){toast(err.message,'bad');}finally{setStatus('Engine Pro 3.1.1 pronto');}}
async function removeBg(){const e=findEl(state.primary),src=selectedImageSource(e);if(!src)return toast('Selecione uma imagem ou um Produto Vivo com imagem.');openModal('REMOVER FUNDO • SR IA AVANÇADA',`<p class="hint">A SR IA primeiro identifica o objeto principal e só depois cria a máscara. Os modos precisos usam bordas, cor do fundo, componentes conectados e refinamento de contorno para evitar cortar embalagem, folhas, alças e detalhes finos.</p><div class="variationGrid bgModes"><div class="variation"><strong>RÁPIDO</strong><p>Prévia leve para imagens simples.</p><button data-bg-mode="RAPIDO">USAR RÁPIDO</button></div><div class="variation"><strong>PRECISO</strong><p>Mais iterações e borda refinada.</p><button data-bg-mode="PRECISO">USAR PRECISO</button></div><div class="variation"><strong>PRODUTO</strong><p>Pacotes, caixas, latas, garrafas e bandejas.</p><button class="primary" data-bg-mode="PRODUTO">USAR PRODUTO</button></div><div class="variation"><strong>ALIMENTO / HORTIFRUTI</strong><p>Contornos irregulares, folhas, frutas, pães e carnes.</p><button data-bg-mode="ALIMENTO">USAR ALIMENTO</button></div></div><div class="bgOptions"><label><input id="bgKeepShadow" type="checkbox" checked> Preservar sombra natural suave</label><label>Refino da borda <input id="bgFeather" type="range" min="0" max="4" step="0.2" value="1.4"></label></div>`);$$('[data-bg-mode]').forEach(b=>b.onclick=()=>runRemoveBg(b.dataset.bgMode));}
function applyImageControl(key,value){const e=findEl(state.primary);if(!e||e.type!=='image')return;e.style=e.style||{};e.style[key]=Number(value);markDirty();renderStage();renderProperties();}

async function aiReview(){try{const r=await postJSON('/api/ai/analyze',{page:page(),project:state.project,campaign:state.currentCampaign||{name:state.project.title}});let extraPenalty=0;for(const e of page().elements){if(e.type==='text'){const f=e.style?.font||'Segoe UI';if(document.fonts&& !document.fonts.check(`12px "${f}"`)){r.issues.push({severity:'warning',kind:'visual',message:`Fonte '${f}' não está disponível neste computador; será usada uma substituta.`});extraPenalty+=2;}}const src=e.type==='image'?e.url:(e.type==='product'?(e.product?.image_url||e.imageUrl):'');if(src){try{const im=await loadImage(src);if(im.naturalWidth<(e.w||1)*.75||im.naturalHeight<(e.h||1)*.55){r.issues.push({severity:'warning',kind:'visual',message:`Imagem de '${e.name||labelFor(e)}' pode perder qualidade na exportação.`});extraPenalty+=3;}}catch{}}}r.visual=Math.max(0,r.visual-extraPenalty);r.overall=Math.round(r.visual*.42+r.data*.33+r.commercial*.25);state.lastAnalysis=r;const q=$('#qualityBox').children;q[0].querySelector('b').textContent=r.overall+'%';q[1].querySelector('b').textContent=r.visual+'%';q[2].querySelector('b').textContent=r.commercial+'%';q[3].querySelector('b').textContent=r.data+'%';const box=$('#aiIssues');box.innerHTML='';(r.issues||[]).forEach(i=>{const d=document.createElement('div');d.className=`issue ${i.severity||''}`;d.textContent=i.message;box.append(d);});setPanel('assistant');toast(`Qualidade geral: ${r.overall}%`,'good');return r;}catch(e){toast(e.message,'bad');}}
async function aiCommand(){const instruction=$('#aiPrompt').value.trim();if(!instruction)return toast('Digite uma instrução para a SR IA.');try{const r=await postJSON('/api/ai/command',{instruction,page:page(),project:state.project});snapshot('Antes da SR IA');for(const op of r.operations||[]){if(op.op==='scale_price')for(const e of page().elements)if(e.type==='product'){e.style=e.style||{};e.style.priceSize=(e.style.priceSize||40)*op.factor;}if(op.op==='premiumize')for(const e of page().elements)if(e.type==='product'){e.style={...e.style,shadow:true,radius:18,fill:'#fff'};}if(op.op==='auto_layout')await applyAiLayout(op.mode);if(op.op==='grid')state.grid=!!op.value;if(op.op==='review')await aiReview();}markDirty('SR IA aplicada');snapshot('SR IA comando');renderAll();toast(r.explanation||'Instrução processada.','good');}catch(e){toast(e.message,'bad');}}
async function applyAiLayout(mode='balanced'){
  const prods=page().elements.filter(e=>e.type==='product').map(e=>e.product);if(!prods.length){if(state.campaignItems.length)return fillPage(mode);return toast('Adicione produtos ou selecione uma campanha.');}
  const r=await postJSON('/api/ai/layout',{page:page(),products:prods,mode,campaign:state.currentCampaign||{name:state.project.title}});const cards=page().elements.filter(e=>e.type==='product');for(let i=0;i<cards.length&&i<(r.items||[]).length;i++){const rc=r.items[i].rect;Object.assign(cards[i],{x:rc.x,y:rc.y,w:rc.w,h:rc.h,variant:rc.role==='hero'?'hero':'normal'});}markDirty('Layout SR IA');renderAll();
}
async function aiVariations(){const prods=page().elements.filter(e=>e.type==='product').map(e=>e.product);if(!prods.length)return toast('Adicione produtos primeiro.');try{const r=await postJSON('/api/ai/variations',{page:page(),products:prods,campaign:state.currentCampaign||{name:state.project.title}});openModal('3 PROPOSTAS SR IA',`<div class="variationGrid">${(r.variations||[]).map(v=>`<div class="variation"><strong>${escapeHTML(v.name)}</strong><p>${escapeHTML(v.description)}</p><button data-var="${v.id}">APLICAR</button></div>`).join('')}</div>`);$$('[data-var]').forEach(b=>b.onclick=async()=>{await applyAiLayout(b.dataset.var==='visual'?'balanced':b.dataset.var);snapshot('Variação SR IA');closeModal();renderAll();});}catch(e){toast(e.message,'bad');}}

function renderDataMode(){if(!state.dataMode)return;const tbody=$('#dataRows'),q=$('#dataSearch').value.toLowerCase();tbody.innerHTML='';state.project.pages.forEach((pg,pi)=>pg.elements.filter(e=>e.type==='product').forEach(e=>{const p=e.product||{};if(q&&!`${p.produto} ${p.categoria}`.toLowerCase().includes(q))return;const tr=document.createElement('tr');const fields=['produto','categoria','custo','varejo','promocao','clube','unidade'];tr.innerHTML=`<td>${pi+1}</td>${fields.map(f=>`<td><input data-id="${e.id}" data-field="${f}" value="${escapeHTML(p[f]||'')}"></td>`).join('')}<td>${p.image_path?'OK':'SEM IMAGEM'}</td>`;tbody.append(tr);}));$$('#dataRows input').forEach(i=>i.onchange=()=>{const e=findElAcrossPages(i.dataset.id);if(e){e.product[i.dataset.field]=i.value;markDirty('Modo Dados');snapshot('Dados');renderStage();}});}
function findElAcrossPages(id){for(const pg of state.project.pages){const e=pg.elements.find(x=>x.id===id);if(e)return e;}return (state.project.master.elements||[]).find(x=>x.id===id);}
function toggleDataMode(){state.dataMode=!state.dataMode;$('#dataMode').classList.toggle('hidden',!state.dataMode);renderDataMode();syncProjectControls();}

async function saveAsTemplate(){const name=prompt('Nome do modelo SR:',state.project.title||'Modelo SR');if(!name)return;try{const r=await postJSON('/api/template/save',{project:state.project,name});toast(`Modelo ${r.name} salvo.`,'good');state.bootstrap=await api('/api/bootstrap');buildTemplates();}catch(e){toast(e.message,'bad');}}
async function openSavedTemplate(name){if(state.dirty&&!confirm('Abrir este modelo e substituir o projeto atual?'))return;try{const r=await api(`/api/template/recent?name=${encodeURIComponent(name+'.srtemplate')}`);state.project=r.project;state.project.title='Novo Encarte — '+name;state.project.status='RASCUNHO';state.pageIndex=0;state.history=[];state.future=[];snapshot('Modelo SR aberto');renderAll();toast('Modelo carregado. Vincule a campanha e substitua os produtos.','good');}catch(e){toast(e.message,'bad');}}

async function saveProject(){state.project.title=$('#projectTitle').value.trim()||state.project.title;state.project.status=$('#projectStatus').value;try{const r=await postJSON('/api/project/save',{project:state.project,name:state.project.title});state.dirty=false;setStatus(`Salvo • ${r.name}`);toast('Projeto salvo no SR Studio. O download também será iniciado.','good');if(r.download){const a=document.createElement('a');a.href=r.download;a.download=r.name;a.click();}const b=await api('/api/bootstrap');state.bootstrap=b;buildRecents();}catch(e){toast(e.message,'bad');}}
async function openProjectFile(file){try{const r=await api(`/api/project/open?name=${encodeURIComponent(file.name)}`,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:await file.arrayBuffer()});state.project=r.project;state.pageIndex=0;state.selected=[];state.history=[];state.future=[];snapshot('Projeto aberto');renderAll();toast('Projeto aberto.','good');}catch(e){toast(e.message,'bad');}}
async function openRecent(name){try{const r=await api(`/api/project/recent?name=${encodeURIComponent(name+'.srencarte')}`);state.project=r.project;state.pageIndex=0;state.history=[];state.future=[];snapshot('Projeto recente');renderAll();}catch(e){toast(e.message,'bad');}}
async function recoverProject(){try{const r=await api('/api/recovery');if(!r.project)return toast('Nenhuma recuperação disponível.');state.project=r.project;state.pageIndex=0;state.history=[];snapshot('Recuperação');renderAll();toast('Autosave recuperado.','good');}catch(e){toast(e.message,'bad');}}
function scheduleAutosave(){clearTimeout(state.autosaveTimer);state.autosaveTimer=setTimeout(async()=>{try{await postJSON('/api/autosave',{project:state.project});setStatus('Autosave concluído');}catch{}},1200);}
function createSnapshot(){state.snapshots.push({at:new Date().toISOString(),project:clone(state.project)});if(state.snapshots.length>12)state.snapshots.shift();toast('Snapshot criado.','good');}
function compareSnapshot(){if(!state.snapshots.length)return toast('Crie um snapshot primeiro.');const old=state.snapshots.at(-1).project,now=state.project;let oldCount=old.pages.reduce((a,p)=>a+p.elements.length,0),newCount=now.pages.reduce((a,p)=>a+p.elements.length,0);openModal('COMPARAR VERSÕES',`<p><b>Snapshot:</b> ${old.pages.length} páginas / ${oldCount} elementos</p><p><b>Atual:</b> ${now.pages.length} páginas / ${newCount} elementos</p><p class="hint">A comparação visual lado a lado será ampliada nas próximas revisões do motor; nesta base, snapshots preservam o projeto inteiro para auditoria e recuperação.</p>`);}
function newProject(){if(state.dirty&&!confirm('Criar novo projeto e descartar alterações não salvas?'))return;state.project=blankProject();state.pageIndex=0;state.selected=[];state.history=[];state.future=[];snapshot('Novo projeto');renderAll();}

async function renderPageToDataURL(pg){
  const c=document.createElement('canvas');c.width=pg.width;c.height=pg.height;const ctx=c.getContext('2d');ctx.fillStyle=pg.backgroundColor||'#fff';ctx.fillRect(0,0,c.width,c.height);
  if(pg.backgroundUrl){try{const img=await loadImage(pg.backgroundUrl);ctx.drawImage(img,0,0,c.width,c.height);}catch{}}
  const es=[...(state.project.master.elements||[]),...(pg.elements||[])].filter(e=>!e.hidden).sort((a,b)=>(a.z||0)-(b.z||0));
  for(const e of es)await drawElement(ctx,e);
  return c.toDataURL('image/png');
}
function loadImage(src){return new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=src;});}
async function drawElement(ctx,e){ctx.save();ctx.globalAlpha=e.opacity??1;const cx=(e.x||0)+(e.w||0)/2,cy=(e.y||0)+(e.h||0)/2;ctx.translate(cx,cy);ctx.rotate((e.rotation||0)*Math.PI/180);ctx.translate(-cx,-cy);
  if(e.type==='shape'){const s=e.style||{};ctx.fillStyle=s.fill||'#ddd';ctx.strokeStyle=s.stroke||'transparent';ctx.lineWidth=s.strokeWidth||0;if(e.shape==='circle'){ctx.beginPath();ctx.ellipse(e.x+e.w/2,e.y+e.h/2,e.w/2,e.h/2,0,0,Math.PI*2);ctx.fill();if(ctx.lineWidth)ctx.stroke();}else{roundRect(ctx,e.x,e.y,e.w,e.h,e.shape==='round'?(s.radius||20):0);ctx.fill();if(ctx.lineWidth)ctx.stroke();}}
  else if(e.type==='text'){drawText(ctx,e);}
  else if(e.type==='image'){try{const img=await loadImage(e.url||'');drawFit(ctx,img,e.x,e.y,e.w,e.h,e.style?.fit||'contain');}catch{}}
  else if(e.type==='product'){await drawProduct(ctx,e);}
  else if(e.type==='group'){for(const ch of e.children||[]){const c={...clone(ch),x:e.x+(ch.x||0),y:e.y+(ch.y||0)};await drawElement(ctx,c);}}
  ctx.restore();
}
function roundRect(ctx,x,y,w,h,r){r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function drawFit(ctx,img,x,y,w,h,fit='contain'){const ir=img.width/img.height,tr=w/h;let dw=w,dh=h,dx=x,dy=y;if(fit==='contain'){if(ir>tr){dh=w/ir;dy=y+(h-dh)/2}else{dw=h*ir;dx=x+(w-dw)/2}}else if(fit==='cover'){if(ir>tr){dw=h*ir;dx=x-(dw-w)/2}else{dh=w/ir;dy=y-(dh-h)/2}}ctx.drawImage(img,dx,dy,dw,dh);}
function drawText(ctx,e){const s=e.style||{},size=s.fontSize||32;ctx.fillStyle=s.color||COLORS.text;ctx.font=`${s.italic?'italic ':''}${s.bold?'800':'600'} ${size}px ${s.font||'Segoe UI'}`;ctx.textAlign=s.align==='center'?'center':s.align==='right'?'right':'left';ctx.textBaseline='top';const x=s.align==='center'?e.x+e.w/2:s.align==='right'?e.x+e.w:e.x;wrapText(ctx,e.text||'',x,e.y,e.w,size*(s.lineHeight||1.05),e.h);}
function wrapText(ctx,text,x,y,maxW,lineH,maxH){const words=String(text).split(/\s+/);let line='',yy=y;for(const word of words){const t=line?line+' '+word:word;if(ctx.measureText(t).width>maxW&&line){ctx.fillText(line,x,yy);yy+=lineH;line=word;if(yy+lineH>y+maxH)break;}else line=t;}if(line&&yy<=y+maxH)ctx.fillText(line,x,yy);}
async function drawProduct(ctx,e){const p=e.product||{},s={...PRODUCT_CARD_DEFAULT,...(e.style||{})};ctx.save();ctx.fillStyle=s.fill;roundRect(ctx,e.x,e.y,e.w,e.h,s.radius||14);ctx.fill();if(p.image_url||e.imageUrl){try{const img=await loadImage(p.image_url||e.imageUrl);drawFit(ctx,img,e.x+e.w*.06,e.y+e.h*.04,e.w*.88,e.h*.54,'contain');}catch{}}
  ctx.fillStyle=s.nameColor;ctx.font=`800 ${s.nameSize||Math.max(12,Math.min(22,e.w/16))}px Segoe UI`;ctx.textAlign='center';ctx.textBaseline='top';wrapText(ctx,p.produto||'PRODUTO',e.x+e.w/2,e.y+e.h*.61,e.w*.88,(s.nameSize||15)*1.03,e.h*.14);
  const pr=money(p.promocao||p.clube||p.varejo||'0,00'),fs=s.priceSize||Math.max(30,Math.min(56,e.w/4.9));ctx.fillStyle=s.priceColor;ctx.textBaseline='bottom';ctx.textAlign='right';ctx.font=`900 ${Math.max(11,fs*.28)}px Segoe UI`;ctx.fillText('R$',e.x+e.w*.30,e.y+e.h*.94);ctx.textAlign='center';ctx.font=`900 ${fs}px Segoe UI`;ctx.fillText(pr,e.x+e.w*.57,e.y+e.h*.94);ctx.font=`800 ${Math.max(11,fs*.26)}px Segoe UI`;ctx.textAlign='left';ctx.fillText(p.unidade||'UN',e.x+e.w*.82,e.y+e.h*.94);if(p.clube){ctx.fillStyle=s.accent||COLORS.blue;roundRect(ctx,e.x+e.w*.57,e.y+e.h*.05,e.w*.38,e.h*.09,6);ctx.fill();ctx.fillStyle='#fff';ctx.font=`800 ${Math.max(9,e.w/28)}px Segoe UI`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText((p.promocao&&money(p.promocao)!==money(p.clube))?`CLUBE R$ ${money(p.clube)}`:'CLUBE',e.x+e.w*.76,e.y+e.h*.095);}ctx.restore();}

async function preview(){setStatus('Renderizando prévia...',true);try{const urls=[];for(let i=0;i<state.project.pages.length;i++){setStatus(`Prévia ${i+1}/${state.project.pages.length}...`,true);urls.push(await renderPageToDataURL(state.project.pages[i]));}let idx=state.pageIndex;const o=document.createElement('div');o.className='previewOverlay';o.innerHTML=`<img><div style="display:flex;gap:7px;align-items:center;margin-top:10px"><button data-prev>←</button><span style="color:white;font-size:12px" data-count></span><button data-next>→</button><button data-close>FECHAR PRÉVIA</button></div>`;const paint=()=>{o.querySelector('img').src=urls[idx];o.querySelector('[data-count]').textContent=`Página ${idx+1} / ${urls.length}`;};o.querySelector('[data-prev]').onclick=()=>{idx=(idx-1+urls.length)%urls.length;paint();};o.querySelector('[data-next]').onclick=()=>{idx=(idx+1)%urls.length;paint();};o.querySelector('[data-close]').onclick=()=>o.remove();document.body.append(o);paint();setStatus('Prévia pronta');}catch(e){toast(e.message,'bad');}}
async function exportDialog(){openModal('EXPORTAR',`<div class="variationGrid"><div class="variation"><strong>PNG</strong><p>Todas as páginas em PNG de alta resolução.</p><button data-exp="PNG">EXPORTAR PNG</button></div><div class="variation"><strong>PDF</strong><p>PDF fiel para impressão e compartilhamento.</p><button data-exp="PDF">EXPORTAR PDF</button></div><div class="variation"><strong>PPTX</strong><p>PowerPoint fiel com cada página renderizada.</p><button data-exp="PPTX">EXPORTAR PPTX</button></div></div>`);$$('[data-exp]').forEach(b=>b.onclick=()=>doExport(b.dataset.exp));}
async function doExport(format,force=false){closeModal();setStatus(`Validando ${format}...`,true);try{if(!force){const blocking=[];for(let i=0;i<state.project.pages.length;i++){const a=await postJSON('/api/ai/analyze',{page:state.project.pages[i],project:state.project,campaign:state.currentCampaign||{name:state.project.title}});for(const issue of a.issues||[])if(issue.severity==='error')blocking.push(`Página ${i+1}: ${issue.message}`);}if(blocking.length){openModal('REVISÃO OBRIGATÓRIA',`<p>O SR Studio encontrou <b>${blocking.length}</b> problema(s) de dados/comercial antes da exportação.</p><div class="issueList">${blocking.slice(0,12).map(x=>`<div class="issue error">${escapeHTML(x)}</div>`).join('')}</div><div class="inline" style="margin-top:14px"><button class="wide grow" data-action-local="back">VOLTAR E CORRIGIR</button><button class="wide" data-action-local="force">EXPORTAR MESMO ASSIM</button></div>`);$('[data-action-local="back"]').onclick=closeModal;$('[data-action-local="force"]').onclick=()=>doExport(format,true);setStatus('Exportação aguardando revisão',true);return;}}const pages=[];for(let i=0;i<state.project.pages.length;i++){setStatus(`Renderizando página ${i+1}/${state.project.pages.length}...`,true);pages.push(await renderPageToDataURL(state.project.pages[i]));}const r=await postJSON('/api/export',{format,title:state.project.title,pages,width:state.project.pages[0]?.width||1080,height:state.project.pages[0]?.height||1350});const a=document.createElement('a');a.href=r.download;a.download=r.name;a.click();state.project.status='EXPORTADO';markDirty('Exportado');toast(`${r.name} gerado.`, 'good');setStatus('Exportação concluída');}catch(e){toast(e.message,'bad');setStatus('Falha na exportação',true);}}

function applyPriceStyle(){for(const id of state.selected){const e=findEl(id);if(e?.type==='text'){e.style={...e.style,fontSize:64,bold:true,color:COLORS.blue,align:'center',vAlign:'middle'};}if(e?.type==='product'){e.style={...e.style,priceSize:54,priceColor:COLORS.blue};}}markDirty();snapshot('Estilo preço');renderAll();}
function applyNameStyle(){for(const id of state.selected){const e=findEl(id);if(e?.type==='text')e.style={...e.style,fontSize:24,bold:true,color:COLORS.text,align:'center'};if(e?.type==='product')e.style={...e.style,nameSize:17,nameColor:COLORS.text};}markDirty();snapshot('Estilo nome');renderAll();}
function applyFooterStyle(){for(const id of state.selected){const e=findEl(id);if(e?.type==='text')e.style={...e.style,fontSize:15,bold:true,color:COLORS.navy,align:'center'};}markDirty();snapshot('Estilo rodapé');renderAll();}
function copyStyle(){const e=findEl(state.primary);if(!e)return toast('Selecione um elemento.');state.styleClipboard=clone(e.style||{});toast('Estilo copiado.');}
function pasteStyle(){if(!state.styleClipboard||!state.selected.length)return;for(const id of state.selected){const e=findEl(id);if(e)e.style=clone(state.styleClipboard);}markDirty();snapshot('Colar estilo');renderAll();}
function addComment(){if(!state.primary)return toast('Selecione um elemento.');const text=prompt('Comentário de revisão:');if(!text)return;state.project.comments=state.project.comments||[];state.project.comments.push({id:uid('comment'),elementId:state.primary,pageId:page().id,text,createdAt:new Date().toISOString(),done:false});markDirty('Comentário adicionado');toast('Comentário salvo no projeto.','good');}
function applyCurrentFont(){applyFontToSelection($('#fontSelect')?.value);}
function applyQuickTextStyle(key,value){const e=state.primary?findEl(state.primary):null;if(!e||e.type!=='text')return;e.style=e.style||{};e.style[key]=value;markDirty('Texto alterado');snapshot('Texto');renderAll();}
function addQR(){const url=prompt('Cole o link/QR desejado:','https://');if(!url)return;addElement({type:'text',name:'QR / Link',text:'QR',x:820,y:1120,w:140,h:140,style:{fontSize:48,bold:true,color:'#111',align:'center',vAlign:'middle'},metadata:{url}});toast('Marcador QR criado. A geração visual do QR será adicionada ao motor de elementos.');}


// ============================================================================
// SR STUDIO 3.1 — ENCARTES ENGINE PRO
// ============================================================================
function allProjectElements(){const out=[];(state.project?.pages||[]).forEach((pg,pi)=>(pg.elements||[]).forEach(e=>out.push({e,pg,pi})));return out;}
function projectProductElements(){return allProjectElements().filter(x=>x.e.type==='product');}
function selectedEls(){return state.selected.map(findEl).filter(Boolean);}
function applyProOperations(ops=[]){if(!ops.length)return 0;snapshot('Antes da SR IA Pro');let n=0;for(const op of ops){const e=findEl(op.elementId);if(!e||e.locked)continue;if(op.op==='rect'){for(const k of ['x','y','w','h'])if(Number.isFinite(Number(op[k])))e[k]=Number(op[k]);n++;}}if(n){markDirty('Plano SR IA aplicado');snapshot('SR IA Pro');renderAll();}return n;}
async function aiOrchestrate(){
  const depth=($('#aiDepth')?.value||'MÁXIMO').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
  const scope=$('#aiScope')?.value||'PAGE',command=$('#aiPrompt')?.value||'Analise e melhore este encarte com prioridade para qualidade visual, comercial e fidelidade.';
  setStatus(`SR IA Orchestrator • ${depth}...`,true);
  try{const r=await postJSON('/api/ai/orchestrate',{project:state.project,page:page(),selected:state.selected,depth,scope,command,intent:command,generatePlan:true});state.pro.lastOrchestration=r;
    const cards=Object.entries(r.agents||{}).map(([k,v])=>`<div class="agentScore"><b>${escapeHTML(k)}</b><strong>${Math.round(v.score||0)}%</strong></div>`).join('');
    const issues=(r.issues||[]).slice(0,14).map(i=>`<div class="issue ${i.severity||''}"><b>${escapeHTML(i.agent||'IA')}</b> — ${escapeHTML(i.message)}</div>`).join('')||'<div class="hint">Nenhum problema importante detectado.</div>';
    openModal('SR IA ORCHESTRATOR — ANÁLISE MÁXIMA',`<div class="proScoreHero"><b>${r.overall}%</b><span>QUALIDADE CONSOLIDADA</span></div><div class="agentGrid">${cards}</div><div class="sectionTitle">ANÁLISE</div><div class="issueList">${issues}</div><p class="hint">${escapeHTML(r.explanation||'')}</p><div class="inline"><button class="grow" id="proDiscard">MANTER ORIGINAL</button><button class="grow primary" id="proApply">APLICAR PLANO SEGURO (${(r.operations||[]).length})</button></div>`);
    $('#proDiscard').onclick=closeModal;$('#proApply').onclick=()=>{const n=applyProOperations(r.operations||[]);closeModal();toast(`${n} ajuste(s) aplicado(s). Preços e custos não foram alterados.`,'good');};
    setStatus('SR IA Orchestrator concluído');
  }catch(e){toast(e.message,'bad');setStatus('Falha no Orchestrator',true);}
}
async function campaignCenter(){setStatus('Analisando campanha...',true);try{const r=await postJSON('/api/campaign-center',{project:state.project});const box=$('#campaignCenterCards');if(box)box.innerHTML=`<div><b>${r.products}</b><span>Produtos</span></div><div><b>${r.pages}</b><span>Páginas</span></div><div><b>${r.images?.ready||0}/${r.products}</b><span>Imagens</span></div><div><b>${r.quality||0}%</b><span>Qualidade</span></div><div><b>${r.blocking||0}</b><span>Bloqueios</span></div>`;toast(r.ready?'Campanha pronta para produção.':'Campanha analisada — há pontos para revisão.',r.ready?'good':'');setStatus('Central de Campanha atualizada');return r;}catch(e){toast(e.message,'bad');}}
async function preflightPro(){setStatus('Executando preflight profissional...',true);try{const r=await postJSON('/api/preflight-pro',{project:state.project});const issues=(r.issues||[]).map(i=>`<div class="issue ${i.severity||''}">${escapeHTML(i.message)}</div>`).join('')||'<div class="issue good">Nenhum problema encontrado.</div>';openModal('PREFLIGHT PROFISSIONAL',`<div class="proScoreHero"><b>${r.score||0}%</b><span>QUALIDADE GERAL</span></div><div class="preflightChecks"><span>${r.checks?.pages||0} páginas</span><span>${r.checks?.products||0} produtos</span><span>${r.checks?.fonts||0} fontes</span><span>${r.checks?.blocking||0} bloqueios</span></div><div class="issueList">${issues}</div>`);setStatus(r.ok?'Preflight aprovado':'Preflight requer revisão',!r.ok);return r;}catch(e){toast(e.message,'bad');}}
function equalizeSelected(){const es=selectedEls();if(es.length<2)return toast('Selecione pelo menos 2 elementos.');snapshot('Antes de equalizar');const w=es.reduce((a,e)=>a+(e.w||0),0)/es.length,h=es.reduce((a,e)=>a+(e.h||0),0)/es.length;es.forEach(e=>{e.w=w;e.h=h;});markDirty('Seleção equalizada');snapshot('Equalizar');renderAll();}
function normalizeProducts(){const es=(state.selected.length?selectedEls():page().elements.filter(e=>e.type==='product')).filter(e=>e.type==='product');if(!es.length)return toast('Nenhum Produto Vivo nesta página.');snapshot('Antes de normalizar produtos');const heights=es.map(e=>e.h||280).sort((a,b)=>a-b),target=heights[Math.floor(heights.length/2)]||280;es.forEach(e=>{const ratio=(e.w||260)/(e.h||280);e.h=target;e.w=target*ratio;e.style={...(e.style||{}),imageFit:'contain'};});markDirty('Produtos normalizados');snapshot('Normalizar produtos');renderAll();}
function autoBalance(){const es=page().elements.filter(e=>!e.locked&&['product','group','image','text'].includes(e.type));if(es.length<2)return;const minX=Math.min(...es.map(e=>e.x)),maxX=Math.max(...es.map(e=>e.x+e.w)),center=(minX+maxX)/2,dx=page().width/2-center;if(Math.abs(dx)<2)return toast('Página já está equilibrada horizontalmente.','good');snapshot('Antes do equilíbrio');es.forEach(e=>e.x+=dx);markDirty('Página equilibrada');snapshot('Auto Balance');renderAll();}
function selectSimilar(){const base=findEl(state.primary);if(!base)return toast('Selecione um elemento.');const same=page().elements.filter(e=>e.type===base.type&&(base.type!=='text'||((e.style?.font||'')===(base.style?.font||'')))&&(base.type!=='product'||((e.variant||'normal')===(base.variant||'normal'))));state.selected=same.map(e=>e.id);state.primary=state.selected[0]||null;renderAll();toast(`${state.selected.length} elemento(s) semelhante(s) selecionados.`,'good');}
function toggleOutline(){state.pro.outline=!state.pro.outline;document.body.classList.toggle('proOutline',state.pro.outline);toast('Modo Outline '+(state.pro.outline?'ativado':'desativado'));}
function togglePerformance(){state.pro.performance=!state.pro.performance;document.body.classList.toggle('proPerformance',state.pro.performance);toast('Modo Performance '+(state.pro.performance?'ativado':'desativado'));}
function toggleSafeZones(){state.pro.safeZones=!state.pro.safeZones;document.body.classList.toggle('proSafeZones',state.pro.safeZones);renderStage();toast('Áreas seguras '+(state.pro.safeZones?'visíveis':'ocultas'));}
function fitPage(){const sc=$('#stageScroller');if(!sc||!page())return;const availW=Math.max(200,sc.clientWidth-100),availH=Math.max(200,sc.clientHeight-100);state.zoom=clamp(Math.min(availW/page().width,availH/page().height),.2,1.5);if($('#zoomRange'))$('#zoomRange').value=Math.round(state.zoom*100);renderStage();}
function fitSelection(){const es=selectedEls();if(!es.length)return fitPage();const minX=Math.min(...es.map(e=>e.x)),minY=Math.min(...es.map(e=>e.y)),maxX=Math.max(...es.map(e=>e.x+e.w)),maxY=Math.max(...es.map(e=>e.y+e.h)),sc=$('#stageScroller');state.zoom=clamp(Math.min((sc.clientWidth-160)/(maxX-minX),(sc.clientHeight-160)/(maxY-minY)),.2,1.5);if($('#zoomRange'))$('#zoomRange').value=Math.round(state.zoom*100);renderStage();setTimeout(()=>{sc.scrollLeft=Math.max(0,minX*state.zoom-80);sc.scrollTop=Math.max(0,minY*state.zoom-80);},30);}
async function performanceReport(){try{const r=await postJSON('/api/performance-report',{project:state.project});openModal('DIAGNÓSTICO DO ENGINE PRO',`<div class="proScoreHero"><b>${r.level}</b><span>COMPLEXIDADE ${r.complexity}</span></div><div class="preflightChecks"><span>${r.elements} objetos</span><span>${r.images} imagens</span><span>${r.texts} textos</span><span>${r.groups} grupos</span></div><p>${(r.recommendations||[]).map(escapeHTML).join('<br>')}</p>`);}catch(e){toast(e.message,'bad');}}
function pixelPerfect(){openModal('PIXEL PERFECT',`<div class="aiCard"><strong>COMPARAÇÃO VISUAL</strong><span>Use uma página importada em modo FIEL como referência sobre a arte editável.</span></div><p class="hint">Na 3.1 o modo Pixel Perfect preserva a base original e permite trabalhar com transparência de referência. Quando o projeto tiver background importado, ative/desative a referência no canvas.</p><button class="wide" id="ppToggle">ALTERNAR REFERÊNCIA</button>`);$('#ppToggle').onclick=()=>{document.body.classList.toggle('pixelPerfectReference');closeModal();};}
async function createCompleteCampaign(){if(!state.campaignItems.length)return toast('Selecione uma campanha com produtos.');if(!confirm('A SR IA vai reorganizar/criar páginas para a campanha atual. Um snapshot será criado antes. Continuar?'))return;createSnapshot();if(state.campaignItems.length>12)pagesByCategory();else fillPage();setTimeout(()=>aiOrchestrate(),120);}
async function productionPack(){const pre=await preflightPro();if(pre&&!pre.ok)return toast('Corrija os bloqueios do preflight antes do pacote de produção.','bad');closeModal();openModal('PRODUÇÃO OMNICHANNEL',`<div class="aiCard"><strong>FILA DE PRODUÇÃO</strong><span>Feed 1080×1350 • Story/Status 1080×1920 • PDF completo</span></div><p class="hint">Os formatos são gerados a partir do mesmo projeto. Use Magic Resize para revisar composições específicas antes da exportação final.</p><button class="wide primary" id="prodStart">GERAR PDF AGORA</button>`);$('#prodStart').onclick=()=>{closeModal();doExport('PDF');};}



function resolveProjectVariables(text){const vars=state.project?.variables||{};return String(text||'').replace(/\{\{\s*([A-Z0-9_À-Ü-]+)\s*\}\}/gi,(m,k)=>Object.prototype.hasOwnProperty.call(vars,k.toUpperCase())?String(vars[k.toUpperCase()]??''):m);}
function autoFitElement(e){if(!e||e.type!=='text')return false;const st=e.style=e.style||{},raw=resolveProjectVariables(e.text||'');let size=Number(st.fontSize||32),min=Number(st.minFontSize||10),max=Number(st.maxFontSize||size),canvas=autoFitElement._c||(autoFitElement._c=document.createElement('canvas')),ctx=canvas.getContext('2d'),avail=Math.max(20,(e.w||200)-(st.paddingLeft||0)-(st.paddingRight||0)),lines=String(raw).split(/\n/);for(let tries=0;tries<80;tries++){ctx.font=`${st.bold?'800':'600'} ${size}px ${st.font||'Segoe UI'}`;const lineCap=Math.max(...lines.map(x=>ctx.measureText(x).width),0),estLines=Math.max(lines.length,Math.ceil(lineCap/avail)),needH=estLines*size*(st.lineHeight||1.05);if(lineCap<=avail*1.08&&needH<=(e.h||100)*.96)break;size-=1;if(size<=min){size=min;break;}}st.fontSize=Math.min(max,size);return true;}
function autoFitText(){const es=(state.selected.length?selectedEls():page().elements.filter(e=>e.type==='text')).filter(e=>e.type==='text');if(!es.length)return toast('Selecione caixas de texto.');snapshot('Antes do AutoFit');es.forEach(autoFitElement);markDirty('AutoFit aplicado');snapshot('AutoFit');renderAll();toast(`${es.length} texto(s) ajustado(s).`,'good');}
function addProPrice(){const cid=uid('price');snapshot('Antes do preço profissional');const x=180,y=180;const add=e=>{e.id=uid('text');e.type='text';e.priceComponentId=cid;e.z=Date.now()%100000;page().elements.push(e);return e.id;};const ids=[];ids.push(add({name:'Preço • R$',text:'R$',x,y:y+44,w:70,h:42,style:{font:'Segoe UI',fontSize:22,bold:true,color:COLORS.blue,align:'right',vAlign:'middle'}}));ids.push(add({name:'Preço • Reais',text:'29',x:x+72,y,w:150,h:96,templateRole:'PRECO_REAIS',pricePart:'reais',style:{font:'Segoe UI',fontSize:82,bold:true,color:COLORS.blue,align:'right',vAlign:'middle'}}));ids.push(add({name:'Preço • Centavos',text:',90',x:x+224,y:y+7,w:95,h:58,templateRole:'PRECO_CENTAVOS',pricePart:'centavos',persistentPrefix:',',style:{font:'Segoe UI',fontSize:44,bold:true,color:COLORS.blue,align:'left',vAlign:'middle'}}));ids.push(add({name:'Preço • Unidade',text:'UN',x:x+228,y:y+61,w:85,h:30,templateRole:'UNIDADE',style:{font:'Segoe UI',fontSize:18,bold:true,color:COLORS.blue,align:'left',vAlign:'middle'}}));state.selected=ids;state.primary=ids[1];markDirty('Preço profissional adicionado');snapshot('Preço profissional');renderAll();}
function manageVariables(){state.project.variables=state.project.variables||{VALIDADE:'',CIDADE:'',CAMPANHA:state.project.title||'',LOJA:'SR'};const v=state.project.variables;openModal('VARIÁVEIS GLOBAIS',`<p class="hint">Use no texto: <b>{{VALIDADE}}</b>, <b>{{CIDADE}}</b>, <b>{{CAMPANHA}}</b> ou qualquer variável criada.</p><div class="propGroup"><label>VALIDADE<input id="varValidade" value="${escapeHTML(v.VALIDADE||'')}"></label><label>CIDADE<input id="varCidade" value="${escapeHTML(v.CIDADE||'')}"></label><label>CAMPANHA<input id="varCampanha" value="${escapeHTML(v.CAMPANHA||'')}"></label><label>LOJA<input id="varLoja" value="${escapeHTML(v.LOJA||'SR')}"></label></div><button class="wide primary" id="varSave">SALVAR E ATUALIZAR TODAS AS PÁGINAS</button>`);$('#varSave').onclick=()=>{state.project.variables={...v,VALIDADE:$('#varValidade').value,CIDADE:$('#varCidade').value,CAMPANHA:$('#varCampanha').value,LOJA:$('#varLoja').value};markDirty('Variáveis atualizadas');snapshot('Variáveis globais');closeModal();renderAll();};}
function findReplace(){const find=prompt('Localizar texto no projeto:');if(!find)return;const rep=prompt(`Substituir “${find}” por:`,'');if(rep===null)return;snapshot('Antes de localizar/substituir');let n=0;for(const {e} of allProjectElements()){if(e.type==='text'&&String(e.text||'').toLowerCase().includes(find.toLowerCase())){e.text=String(e.text||'').replace(new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),rep);n++;}}if(n){markDirty('Substituição global');snapshot('Localizar/substituir');renderAll();}toast(`${n} texto(s) alterado(s).`,n?'good':'');}
function approveLock(){if(!confirm('Aprovar esta versão e proteger preços, produtos, validade e elementos vinculados?'))return;snapshot('Antes da aprovação');state.project.status='APROVADO';state.project.approvedAt=new Date().toISOString();for(const {e} of allProjectElements()){if(e.type==='product'||e.binding||String(e.templateRole||'').match(/PRECO|UNIDADE|VALIDADE|CLUBE/))e.locked=true;}markDirty('Versão aprovada e protegida');snapshot('Aprovação');renderAll();toast('Versão APROVADA e dados comerciais protegidos.','good');}

function showCommandPalette(){const p=$('#commandPalette');p.classList.remove('hidden');const i=$('#commandInput');i.value='';i.focus();renderCommands('');}
function hideCommandPalette(){$('#commandPalette').classList.add('hidden');}
const commands=[['Novo projeto',newProject],['Salvar projeto',saveProject],['Importar Canva / PPTX',startTemplateImport],['Analisar template com SR IA',analyzeTemplateZones],['Preencher template inteligente',fillSmartTemplate],['Adicionar produto',()=>setPanel('products')],['Adicionar texto',()=>addText('body')],['SR IA: revisar',aiReview],['SR IA: organizar',()=>applyAiLayout('balanced')],['SR IA: 3 propostas',aiVariations],['Magic Resize',()=>setPanel('pages')],['Modo Dados',toggleDataMode],['Exportar',exportDialog],['Página Mestre',toggleMaster],['Agrupar',groupSelected],['Desagrupar',ungroupSelected],['Copiar estilo',copyStyle],['Colar estilo',pasteStyle],['Gerenciador de Fontes',()=>setPanel('text')],['Editar texto selecionado',()=>{if(state.primary)startTextEdit(state.primary);}],['SR IA Orchestrator — máximo',aiOrchestrate],['Central de Campanha',campaignCenter],['Preflight profissional',preflightPro],['Equalizar seleção',equalizeSelected],['Normalizar produtos',normalizeProducts],['Auto Balance',autoBalance],['Modo Outline',toggleOutline],['Modo Performance',togglePerformance],['Ajustar página',fitPage],['Selecionar semelhantes',selectSimilar],['AutoFit de texto',autoFitText],['Adicionar preço profissional',addProPrice],['Variáveis globais',manageVariables],['Localizar/Substituir',findReplace],['Aprovar e proteger projeto',approveLock]];
function renderCommands(q){const box=$('#commandResults');box.innerHTML='';commands.filter(([n])=>n.toLowerCase().includes(q.toLowerCase())).slice(0,10).forEach(([n,fn])=>{const d=document.createElement('div');d.className='commandResult';d.textContent=n;d.onclick=()=>{hideCommandPalette();fn();};box.append(d);});}


async function runUiDiagnostics(show=true){
  const required=['stage','drawer','drawerClose','campaignSelect','productSearch','dataSearch','projectTitle','projectStatus','imageInput','templateInput','projectInput','fontInput','zoomRange','imgBrightness','imgContrast','imgSaturate','imgRadius','commandInput','modal','toastHost','textQuickToolbar','quickFontSelect','quickFontSize','quickBold','quickItalic','quickTextColor','fontSelect'];
  const missing=required.filter(id=>!document.getElementById(id));
  const actions=[...document.querySelectorAll('[data-action]')];
  const unbound=actions.filter(b=>typeof b.onclick!=='function').map(b=>b.dataset.action||b.textContent.trim()).filter(Boolean);
  const tools=[...document.querySelectorAll('.tool')];
  const deadTools=tools.filter(b=>typeof b.onclick!=='function').map(b=>b.dataset.panel||'?');
  const panelNames=tools.map(b=>b.dataset.panel).filter(Boolean);
  const missingPanels=panelNames.filter(n=>!document.querySelector(`[data-panel-body="${n}"]`));
  let server='OK',serverVersion='';
  try{const h=await api('/api/health');serverVersion=h.version||'';const st=await api('/api/selftest');if(!st.ok)server=`SELFTEST ${st.passed}/${st.total}`;}catch(err){server='FALHA: '+err.message;}
  const ok=!missing.length&&!unbound.length&&!deadTools.length&&!missingPanels.length&&server==='OK';
  const health=document.getElementById('uiHealthText');
  if(health){health.textContent=ok?`Interface OK • ${actions.length} ações vinculadas • motor ${serverVersion||'ativo'}`:`Problemas: ${missing.length} controles • ${unbound.length} ações • servidor ${server}`;health.className='hint '+(ok?'good':'bad');}
  const result={ok,missing,unbound,deadTools,missingPanels,actions:actions.length,server,serverVersion};
  if(show){
    const line=(name,arr)=>`<div><b>${name}:</b> ${arr.length?escapeHTML(arr.join(', ')):'OK'}</div>`;
    openModal('DIAGNÓSTICO DO ENCARTES INTELLIGENCE',`<div class="diagnosticBox"><h3>${ok?'✓ INTERFACE FUNCIONAL':'⚠ PROBLEMAS ENCONTRADOS'}</h3><div><b>Motor:</b> ${escapeHTML(server)} ${escapeHTML(serverVersion)}</div><div><b>Botões/ações encontrados:</b> ${actions.length}</div>${line('Controles ausentes',missing)}${line('Ações sem vínculo',unbound)}${line('Ferramentas sem vínculo',deadTools)}${line('Painéis ausentes',missingPanels)}<p class="hint">A versão 3.0.9 impede que um único controle ausente desative todos os demais botões.</p></div>`);
  }
  return result;
}

function bindUI(){
  // Navegação lateral: cada botão é isolado para que uma falha não mate os demais.
  $$('.tool').forEach(b=>{b.onclick=safeHandler(`Painel ${b.dataset.panel}`,()=>setPanel(b.dataset.panel));});
  const drawerClose=document.getElementById('drawerClose');if(drawerClose)drawerClose.onclick=safeHandler('Abrir/fechar painel',()=>{const d=document.getElementById('drawer');if(d)d.style.display=d.style.display==='none'?'block':'none';});

  document.addEventListener('pointermove',safeHandler('Mover elemento',onPointerMove));
  document.addEventListener('pointerup',safeHandler('Finalizar movimento',onPointerUp));
  bindOptionalId('stage','pointerdown',ev=>{if(ev.target.id==='stage'||ev.target.classList.contains('bgLayer'))clearSelection();},'Canvas');
  bindOptionalId('stage','dragover',ev=>{ev.preventDefault();if(ev.dataTransfer)ev.dataTransfer.dropEffect='copy';},'Arrastar arquivo');
  bindOptionalId('stage','drop',ev=>{ev.preventDefault();const s=ev.dataTransfer?.getData('application/x-sr-product');if(s){const pos=toStageCoords(ev),p=JSON.parse(s);addProduct(p,{x:pos.x-130,y:pos.y-150,w:260,h:300});return;}const fs=[...(ev.dataTransfer?.files||[])];if(fs.length){const f=fs[0],ext=(f.name.split('.').pop()||'').toLowerCase();if(ext==='pptx')importTemplate(f);else if(['png','jpg','jpeg','webp','bmp'].includes(ext))uploadImage(f);else toast('Arraste um PPTX ou uma imagem PNG/JPG/WEBP/BMP.','bad');}},'Soltar arquivo');

  bindOptionalId('campaignSelect','change',e=>loadCampaign(e.target.value),'Campanha');
  bindOptionalId('productSearch','input',renderProducts,'Busca de produtos');
  bindOptionalId('dataSearch','input',renderDataMode,'Filtro do modo dados');
  bindOptionalId('projectTitle','change',e=>{if(state.project){state.project.title=e.target.value;markDirty();}},'Título do projeto');
  bindOptionalId('projectStatus','change',e=>{if(state.project){state.project.status=e.target.value;markDirty();}},'Status do projeto');

  bindOptionalId('imageInput','change',e=>{if(e.target.files?.[0])uploadImage(e.target.files[0]);e.target.value='';},'Importar imagem');
  bindOptionalId('templateInput','change',e=>{if(e.target.files?.[0])importTemplate(e.target.files[0]);e.target.value='';},'Importar PPTX');
  bindOptionalId('projectInput','change',e=>{if(e.target.files?.[0])openProjectFile(e.target.files[0]);e.target.value='';},'Abrir projeto');
  bindOptionalId('fontInput','change',async e=>{await importFonts(e.target.files);e.target.value='';},'Importar fontes');

  bindOptionalId('quickFontSelect','change',e=>applyQuickTextStyle('font',e.target.value),'Fonte rápida');
  bindOptionalId('quickFontSize','change',e=>applyQuickTextStyle('fontSize',clamp(Number(e.target.value)||32,6,400)),'Tamanho da fonte');
  const qb=document.getElementById('quickBold');if(qb)qb.onclick=safeHandler('Negrito',()=>{const e=state.primary?findEl(state.primary):null;if(e?.type==='text')applyQuickTextStyle('bold',!e.style?.bold);});
  const qi=document.getElementById('quickItalic');if(qi)qi.onclick=safeHandler('Itálico',()=>{const e=state.primary?findEl(state.primary):null;if(e?.type==='text')applyQuickTextStyle('italic',!e.style?.italic);});
  bindOptionalId('quickTextColor','input',e=>{const el=state.primary?findEl(state.primary):null;if(el?.type==='text'){el.style=el.style||{};el.style.color=e.target.value;state.dirty=true;scheduleAutosave();renderStage();}},'Cor de texto');
  bindOptionalId('quickTextColor','change',e=>applyQuickTextStyle('color',e.target.value),'Confirmar cor');

  bindOptionalId('zoomRange','input',e=>{state.zoom=Number(e.target.value)/100;renderStage();},'Zoom');
  const zout=document.querySelector('[data-zoom="out"]');if(zout)zout.onclick=safeHandler('Diminuir zoom',()=>{state.zoom=clamp(state.zoom-.1,.2,1.5);renderStage();});
  const zin=document.querySelector('[data-zoom="in"]');if(zin)zin.onclick=safeHandler('Aumentar zoom',()=>{state.zoom=clamp(state.zoom+.1,.2,1.5);renderStage();});

  bindOptionalId('imgBrightness','input',e=>applyImageControl('brightness',e.target.value),'Brilho');
  bindOptionalId('imgContrast','input',e=>applyImageControl('contrast',e.target.value),'Contraste');
  bindOptionalId('imgSaturate','input',e=>applyImageControl('saturate',e.target.value),'Saturação');
  bindOptionalId('imgRadius','input',e=>applyImageControl('radius',e.target.value),'Arredondamento');
  bindOptionalId('commandInput','input',e=>renderCommands(e.target.value),'Busca de comandos');
  bindOptionalId('commandPalette','click',e=>{if(e.target.id==='commandPalette')hideCommandPalette();},'Paleta de comandos');

  $$('[data-add-shape]').forEach(b=>{b.onclick=safeHandler(`Adicionar forma ${b.dataset.addShape}`,()=>addShape(b.dataset.addShape));});
  $$('[data-add-text]').forEach(b=>{b.onclick=safeHandler(`Adicionar texto ${b.dataset.addText}`,()=>addText(b.dataset.addText));});
  $$('[data-color]').forEach(b=>{b.onclick=safeHandler('Aplicar cor',()=>{for(const id of state.selected){const e=findEl(id);if(!e)continue;e.style=e.style||{};if(e.type==='text')e.style.color=b.dataset.color;else if(e.type==='product')e.style.accent=b.dataset.color;else e.style.fill=b.dataset.color;}markDirty();snapshot('Cor');renderAll();});});

  const handlers={
    aiOrchestrate,campaignCenter,preflightPro,createCompleteCampaign,productionPack,equalizeSelected,normalizeProducts,autoBalance,selectSimilar,toggleOutline,togglePerformance,toggleSafeZones,fitPage,fitSelection,performanceReport,pixelPerfect,autoFitText,addProPrice,manageVariables,findReplace,approveLock,
    new:newProject,open:()=>document.getElementById('projectInput')?.click(),save:saveProject,undo,redo,preview,export:exportDialog,
    importTemplate:startTemplateImport,uploadImage:startImageImport,importFont:()=>document.getElementById('fontInput')?.click(),applyFont:applyCurrentFont,
    syncCampaign,fillPage,replaceCampaign:replaceCampaignKeepingLayout,pagesByCategory,addSlot,autoSlots,analyzeTemplateZones,fillSmartTemplate,saveAsTemplate,addQR,
    group:groupSelected,ungroup:ungroupSelected,saveComponent,searchProductImage,removeBg,fitContain:()=>setImageFit('contain'),fitCover:()=>setImageFit('cover'),circleMask,extractPalette,
    addBrandTitle,addSmartBadge,addValidity,addFooter,moveToMaster,toggleMaster,aiReview,aiCommand,aiLayoutBalanced:()=>applyAiLayout('balanced'),aiLayoutHero:()=>applyAiLayout('hero'),aiVariations,
    addPage,duplicatePage,magicResize,toggleDataMode,snapshot:createSnapshot,compareSnapshot,alignLeft:()=>alignSelected('left'),alignCenter:()=>alignSelected('center'),alignRight:()=>alignSelected('right'),
    distributeH:()=>distributeSelected('h'),distributeV:()=>distributeSelected('v'),bringFront,sendBack,duplicate:duplicateSelected,lock:lockSelected,comments:addComment,layerUp:()=>layerMove('up'),layerDown:()=>layerMove('down'),
    applyPriceStyle,applyNameStyle,applyFooterStyle,copyStyle,closeModal,toggleGrid:()=>{state.grid=!state.grid;renderStage();},toggleSnap:()=>{state.snap=!state.snap;toast('Snap '+(state.snap?'ativado':'desativado'));},diagnostics:()=>runUiDiagnostics(true)
  };
  $$('[data-action]').forEach(b=>{const a=b.dataset.action;if(b.onclick)return;const fn=handlers[a];if(fn)b.onclick=safeHandler(`Ação ${a}`,fn);else{console.warn('[SR 3.1.1] Ação sem implementação:',a);b.classList.add('actionUnavailable');}});

  const errClose=document.getElementById('uiErrorClose');if(errClose)errClose.onclick=()=>document.getElementById('uiErrorBanner')?.classList.add('hidden');
  window.addEventListener('beforeunload',e=>{if(state.dirty){e.preventDefault();e.returnValue='';}});
  document.addEventListener('keydown',safeHandler('Atalho de teclado',onKey));
  setTimeout(()=>runUiDiagnostics(false).catch(err=>reportUiError(err,'Diagnóstico inicial')),600);
}
function setImageFit(fit){const e=findEl(state.primary);if(!e||e.type!=='image')return toast('Selecione uma imagem.');e.style=e.style||{};e.style.fit=fit;markDirty();snapshot('Ajuste imagem');renderAll();}
async function extractPalette(){const e=findEl(state.primary);if(!e||e.type!=='image'||!e.url)return toast('Selecione uma imagem.');try{const img=await loadImage(e.url),c=document.createElement('canvas');c.width=48;c.height=48;const ctx=c.getContext('2d');ctx.drawImage(img,0,0,48,48);const data=ctx.getImageData(0,0,48,48).data,bins=new Map();for(let i=0;i<data.length;i+=16){if(data[i+3]<100)continue;const r=Math.round(data[i]/32)*32,g=Math.round(data[i+1]/32)*32,b=Math.round(data[i+2]/32)*32;if(r+g+b>735||r+g+b<45)continue;const key=[clamp(r,0,255),clamp(g,0,255),clamp(b,0,255)].join(',');bins.set(key,(bins.get(key)||0)+1);}const colors=[...bins.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k])=>'#'+k.split(',').map(n=>Number(n).toString(16).padStart(2,'0')).join(''));openModal('PALETA DA IMAGEM',`<div class="brandPalette">${colors.map(c=>`<button data-pal="${c}" style="--c:${c}" title="${c}"></button>`).join('')}</div><p class="hint">Clique em uma cor para aplicar ao elemento selecionado e registrar como cor de destaque do projeto.</p>`);$$('[data-pal]').forEach(b=>b.onclick=()=>{e.style=e.style||{};if(e.type==='text')e.style.color=b.dataset.pal;else e.style.accent=b.dataset.pal;state.project.brand.accent=b.dataset.pal;markDirty('Paleta aplicada');snapshot('Paleta');closeModal();renderAll();});}catch(err){toast('Não foi possível extrair a paleta: '+err.message,'bad');}}
function circleMask(){const e=findEl(state.primary);if(!e||e.type!=='image')return toast('Selecione uma imagem.');e.style=e.style||{};e.style.radius=Math.round(Math.min(e.w,e.h)/2);markDirty('Máscara circular');snapshot('Máscara');renderAll();}

function onKey(e){
  const tag=(document.activeElement?.tagName||'').toLowerCase(),typing=['input','textarea','select'].includes(tag)||document.activeElement?.isContentEditable;
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();showCommandPalette();return;}
  if(e.key==='Escape'){if(state.textEditing){finishTextEdit(true);return;}hideCommandPalette();closeModal();clearSelection();return;}
  if(typing)return;
  if((e.key==='Enter'||e.key==='F2')&&state.primary&&findEl(state.primary)?.type==='text'){e.preventDefault();startTextEdit(state.primary);return;}
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();undo();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){e.preventDefault();duplicateSelected();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='g'){e.preventDefault();e.shiftKey?ungroupSelected():groupSelected();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='c'){state.clipboard=state.selected.map(id=>clone(findEl(id))).filter(Boolean);}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='v'){if(state.clipboard.length){snapshot('Antes de colar');const ids=[];for(const c0 of state.clipboard){const c=clone(c0);c.id=uid(c.type);c.x+=20;c.y+=20;page().elements.push(c);ids.push(c.id);}state.selected=ids;state.primary=ids[0];markDirty();snapshot('Colar');renderAll();}}
  else if(e.key==='Delete'||e.key==='Backspace')deleteSelected();
  else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)&&state.selected.length){e.preventDefault();const step=e.shiftKey?10:1;for(const id of state.selected){const el=findEl(id);if(!el||el.locked)continue;if(e.key==='ArrowLeft')el.x-=step;if(e.key==='ArrowRight')el.x+=step;if(e.key==='ArrowUp')el.y-=step;if(e.key==='ArrowDown')el.y+=step;}markDirty();renderAll();}
}

function setupAutosaveLoop(){setInterval(()=>{if(state.dirty)scheduleAutosave();},15000);}

bindUI();bootstrap();setupAutosaveLoop();
})();
