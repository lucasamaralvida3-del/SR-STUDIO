from __future__ import annotations
import json, os, subprocess, threading, urllib.request, webbrowser
from pathlib import Path
import tkinter as tk


def _cfg():
    p=Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'SRStudio' / 'Config' / 'launcher.json'
    try:
        return json.loads(p.read_text(encoding='utf-8-sig'))
    except Exception:
        return {'encartes_cloud_url':'http://127.0.0.1:3000'}

def cloud_url():
    return (_cfg().get('encartes_cloud_url') or 'http://127.0.0.1:3000').rstrip('/')

def preload_encarte3_data(force=False):
    # O editor pesado não é mais pré-carregado pelo Desktop Core.
    # Retorno mantido para compatibilidade com SR_Studio_Gerador.py.
    return 0

def _open_app(url:str):
    # Tenta Edge em modo app (janela própria), sem exigir instalação adicional.
    candidates=[
        os.path.expandvars(r'%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe'),
        os.path.expandvars(r'%ProgramFiles%\Microsoft\Edge\Application\msedge.exe'),
        os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe'),
    ]
    for exe in candidates:
        if exe and os.path.exists(exe):
            try:
                subprocess.Popen([exe, f'--app={url}', '--start-maximized'])
                return
            except Exception:
                pass
    webbrowser.open(url)

class Encartes3Panel(tk.Frame):
    def __init__(self,parent,app=None,pal=None):
        pal=pal or {}
        bg=pal.get('BG','#0B1220'); card=pal.get('CARD','#111B2E'); fg=pal.get('TEXT','#EAF2FF'); blue=pal.get('BLUE2','#22A7F0')
        super().__init__(parent,bg=bg)
        self.url=cloud_url(); self.status=tk.StringVar(value='Verificando conexão com o Encartes Intelligence Cloud...')
        box=tk.Frame(self,bg=card,highlightthickness=1,highlightbackground=pal.get('BORDER','#26344D'))
        box.pack(expand=True,fill='both',pad=28)
        tk.Label(box,text='ENCARTES INTELLIGENCE CLOUD',bg=card,fg=blue,font=('Segoe UI',21,'bold')).pack(pady=(34,5))
        tk.Label(box,text='Motor avançado de encartes executado fora do Desktop Core',bg=card,fg=fg,font=('Segoe UI',11)).pack()
        tk.Label(box,textvariable=self.status,bg=card,fg=pal.get('MUTED','#A7B4C9'),font=('Segoe UI',10)).pack(pady=(20,12))
        tk.Button(box,text='ABRIR ENCARTE INTELLIGENCE',command=lambda:_open_app(self.url),bg=blue,fg='white',activebackground=blue,activeforeground='white',bd=0,padx=28,pady=12,font=('Segoe UI',11,'bold'),cursor='hand2').pack(pady=8)
        tk.Button(box,text='ATUALIZAR STATUS',command=self.check,bg=pal.get('SIDEBAR_HOVER','#1A2942'),fg=fg,bd=0,padx=18,pady=8,cursor='hand2').pack(pady=5)
        tk.Label(box,text='O restante do SR Studio continua no Desktop. Apenas o editor de encartes usa o motor Cloud.',bg=card,fg=pal.get('MUTED','#A7B4C9'),font=('Segoe UI',9),wraplength=620,justify='center').pack(pady=(24,10))
        self.after(200,self.check)
    def check(self):
        self.status.set('Verificando conexão...')
        def run():
            ok=False
            try:
                with urllib.request.urlopen(self.url,timeout=3) as r: ok=200 <= getattr(r,'status',200) < 500
            except Exception: ok=False
            self.after(0,lambda:self.status.set('● ONLINE — pronto para editar encartes' if ok else '● OFFLINE — verifique internet/endereço do Cloud'))
        threading.Thread(target=run,daemon=True).start()
